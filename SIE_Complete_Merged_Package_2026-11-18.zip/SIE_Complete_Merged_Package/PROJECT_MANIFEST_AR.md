# Manifest — SIE Complete Merged Package

## الجذر
- `README_AR.md` — نقطة البداية والحدود.
- `PROJECT_MANIFEST_AR.md` — هذا الملف.
- `SIE_Prototype.html` — نسخة HTML مستقلة للنموذج المحلي.

## `docs/` — مواصفات المشروع الفعالة
- `00_PROJECT_HISTORY_AND_PHASES.md`
- `01_PRODUCT_VISION_SCOPE.md`
- `02_PRODUCT_PARTS_AND_MODULES.md`
- `03_PROBLEMS_GOALS_METRICS.md`
- `04_IDEATION_CONCEPTS.md`
- `05_USER_JOURNEY_AND_FLOWS.md`
- `07_SENSING_DATA_AND_INTEGRATIONS.md`
- `08_AI_ASSISTANT_BEHAVIOR.md`
- `09_PROTOTYPE_SCOPE_AND_QA.md`
- `10_DECISION_LOG.md`
- `11_OPEN_ISSUES_AND_RISKS.md`
- `12_MASTER_BUILD_BRIEF_AR.md`
- `14_MODULE_SPECIFICATIONS.md`
- `16_MIDAD_AND_RIWAQ_SPEC_AR.md`
- `17_STUDYFLOW_UX_UI_AUDIT_AR.md`

ملفا التصميم السابقان ولقطات الواجهات نُقلا إلى `legacy/retired_design_reference/` لأنهما تاريخيان وغير ملزمين.

## `knowledge_base/` — قاعدة المعرفة
- `SIE_Knowledge_Pack.json` — بيانات قابلة للاستهلاك الآلي.
- `SIE_Knowledge_Pack.xlsx` — نسخة مراجعة بشرية.
- `README_AR.md` — شرح القاعدة ومصادرها وحدودها.
- `AI_HANDOFF_PROMPT_AR.md` — تعليمات استخدام قاعدة المعرفة.
- `TEACHER_POSITION_STRATEGY_AR.md` — استراتيجية التحقق من موضع الطالب مع المدرس.

## `prompts/` — تعليمات التنفيذ
- `01_MASTER_BUILD_AND_EXECUTION_PROMPT_AR.md` — برومبت بناء SIE بالكامل.
- `02_STUDYFLOW_UI_UX_FIX_PROMPT_AR.md` — برومبت إصلاح واجهة الموقع وفق findings مثبتة.
- `03_HOW_TO_USE_THIS_PACKAGE_AR.md` — طريقة تسليم الحزمة وتشغيل الوكيل.

## `prototype/` و`qa/`
- نموذج الواجهة المحلية وملف README الخاص به.
- Playwright smoke tests وشرح تشغيلها.

## `assets/`
- مخططات SVG التقنية: البنية، تدفق جمع البيانات، وتدخل المساعد.

## `legacy/`
ملفات ومخرجات سابقة محفوظة للتاريخ والمقارنة فقط. لا تُستخدم كمرجع إلزامي أو تستبدل القرارات الحالية.

# فهرس الصور والرسومات

## صور النموذج الجديد

- `prototype-desktop.png` — الواجهة الرئيسية على الكمبيوتر.
- `prototype-tablet.png` — الواجهة الرئيسية على التابلت.
- `prototype-mobile.png` — الواجهة الرئيسية على الهاتف.
- `prototype-plan.png` — شاشة الخطة.
- `prototype-subjects.png` — شاشة المواد.
- `prototype-progress.png` — شاشة التقدم.
- `prototype-intelligence.png` — شاشة المساعد السياقي.

## مخططات المنتج المحدّثة

لكل مخطط نسخة SVG قابلة للتحرير ونسخة PNG للعرض السريع:

- `sie-architecture.svg/png` — تقسيم Foundation / Core Intelligence / Product Completion.
- `sensing-flow.svg/png` — تدفق جمع بيانات الطالب بأقل تدخل.
- `navigation-map.svg/png` — Bottom Navigation الموحد على كل الشاشات.
- `assistant-intervention.svg/png` — من اكتشاف المشكلة إلى تفسيرها والإجراء الواضح.

## الصور السابقة المحفوظة

داخل `legacy/`:

- `student-intelligence-ecosystem-preview.png` — لقطة التصميم الداكن السابق.
- `student-intelligence-ecosystem-preview-light.png` — النسخة الفاتحة السابقة.

هذه الصور تاريخية وتعرض واجهة Sidebar/Dashboard سابقة، ولا تمثل الاتجاه المعتمد حاليًا.


## لقطات المراجعة البصرية الثانية — 16 نوفمبر 2026

- `prototype-desktop.png` — الصفحة الرئيسية بعد المراجعة الثانية.
- `prototype-tablet.png` — الصفحة الرئيسية على التابلت.
- `prototype-mobile.png` — الصفحة الرئيسية على الهاتف.
- `prototype-plan.png` — شاشة الخطة.
- `prototype-subjects.png` — شاشة المواد.
- `prototype-progress.png` — سجل التقدم القائم على الأدلة دون أشرطة نسب.
- `prototype-intelligence.png` — شاشة المساعد (المعرّف البرمجي القديم intelligence محفوظ للتوافق، والاسم المرئي للمستخدم «المساعد»).

الصور القديمة محفوظة في `legacy/` ولا تمثل الاتجاه البصري المعتمد حاليًا.

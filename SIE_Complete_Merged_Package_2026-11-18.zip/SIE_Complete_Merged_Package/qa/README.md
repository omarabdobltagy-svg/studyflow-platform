# اختبارات المطور

`smoke_test_playwright.py` هو اختبار دخاني اختياري تم تشغيله في بيئة Chromium. يحتاج Python وPlaywright وChromium مثبتًا. لا تحتاج إلى تشغيله لفتح النموذج على الهاتف؛ يكفي فتح `prototype/index.html`.

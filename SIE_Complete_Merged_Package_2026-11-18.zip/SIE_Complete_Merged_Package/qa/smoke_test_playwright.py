from playwright.sync_api import sync_playwright
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]
ASSETS=BASE/'assets'
html=(BASE/'prototype'/'index.html').read_text(encoding='utf-8')
errors=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    desktop=browser.new_page(viewport={'width':1440,'height':1000}, device_scale_factor=1)
    desktop.set_default_timeout(5000)
    desktop.on('pageerror', lambda e: errors.append('desktop: '+str(e)))
    desktop.set_content(html, wait_until='domcontentloaded')
    desktop.wait_for_timeout(200)
    desktop.screenshot(path=str(ASSETS/'prototype-desktop.png'), full_page=True)
    assert desktop.locator('#screen-today').is_visible()
    # Core navigation and screen snapshots
    for name in ['plan','subjects','progress','intelligence']:
        desktop.locator(f'[data-screen="{name}"]').click()
        assert desktop.locator(f'#screen-{name}').is_visible()
        desktop.screenshot(path=str(ASSETS/f'prototype-{name}.png'), full_page=True)
    # Plan day selection
    desktop.locator('[data-screen="plan"]').click()
    desktop.locator('[data-day="الثلاثاء"]').click()
    assert desktop.locator('[data-day="الثلاثاء"]').get_attribute('class').find('active') >= 0
    # Subject details and search
    desktop.locator('[data-screen="subjects"]').click()
    desktop.locator('[data-subject="history"]').click()
    assert desktop.locator('#subjectDetail').is_visible()
    desktop.locator('#subjectSearch').fill('Grammar')
    assert desktop.locator('[data-subject="english"]').is_visible()
    assert not desktop.locator('[data-subject="history"]').is_visible()
    # Assistant contextual response
    desktop.locator('[data-screen="intelligence"]').click()
    desktop.locator('#chatInput').fill('ما سبب التأخير؟')
    desktop.locator('#chatForm button').click()
    assert 'سبب التأخير' in desktop.locator('#chatBody').inner_text()
    desktop.locator('#chatReviewPlan').click()
    assert desktop.locator('#modalBackdrop').is_visible()
    desktop.locator('#acceptAdjustment').click()
    assert desktop.locator('#modalBackdrop').is_hidden()
    # Demo account; ensure no backend submission
    desktop.locator('#accountBtn').click()
    desktop.locator('input[name="name"]').fill('طالب تجريبي')
    desktop.locator('input[name="phone"]').fill('01000000000')
    desktop.locator('input[name="password"]').fill('DemoPass123')
    desktop.locator('#signupForm button[type="submit"]').click()
    assert desktop.locator('#modalBackdrop').is_hidden()
    assert desktop.locator('#accountBtn').inner_text()=='ط'
    # Source disclosure
    desktop.locator('#sourcesTop').click()
    assert 'لا يطلب SIE كلمات مرور' in desktop.locator('#modalContent').inner_text()
    desktop.locator('#closeModal').click()
    # Start and finish a focus session
    desktop.locator('[data-screen="today"]').click()
    desktop.locator('#startSession').click()
    assert desktop.locator('#timerDisplay').is_visible()
    desktop.locator('#finishSession').click()
    assert 'تم تسجيل جلسة تجريبية' in desktop.locator('#toast').inner_text()
    # Responsive tablet/mobile checks
    for name,width,height in [('tablet',768,1024),('mobile',390,844)]:
        pg=browser.new_page(viewport={'width':width,'height':height}, device_scale_factor=1, is_mobile=(name=='mobile'), has_touch=(name=='mobile'))
        pg.set_default_timeout(5000)
        pg.on('pageerror', lambda e, n=name: errors.append(n+': '+str(e)))
        pg.set_content(html, wait_until='domcontentloaded'); pg.wait_for_timeout(150)
        pg.screenshot(path=str(ASSETS/f'prototype-{name}.png'), full_page=True)
        assert pg.locator('.bottom-nav').is_visible()
        assert pg.locator('.bottom-nav .nav-item').count()==5
        dims=pg.evaluate('({sw:document.documentElement.scrollWidth,cw:document.documentElement.clientWidth})')
        assert dims['sw'] <= dims['cw']+1, (name,dims)
        pg.locator('[data-screen="intelligence"]').click()
        assert pg.locator('#screen-intelligence').is_visible()
        pg.close()
    browser.close()
if errors:
    raise SystemExit('JS errors: '+repr(errors))
print('PASS — navigation (5 sections), day switching, subject details/search, contextual assistant, plan adjustment, demo signup, source disclosure, focus session, viewport responsiveness (1440/768/390), no horizontal overflow, no JS errors.')

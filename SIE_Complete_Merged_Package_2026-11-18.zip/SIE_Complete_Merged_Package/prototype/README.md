# SIE Prototype

Open `index.html` in a modern browser. No build step, package install, API key, or server is required.

The UI is a local demonstration. All student-facing data is fictional. Form submissions are not sent anywhere; the app does not store passwords or phone numbers. OAuth, real account creation, AI inference, source integrations, and cloud persistence are not implemented.

The prototype uses one bottom navigation component at every viewport size and implements five primary surfaces: Today, Plan, Subjects, Progress, Intelligence.

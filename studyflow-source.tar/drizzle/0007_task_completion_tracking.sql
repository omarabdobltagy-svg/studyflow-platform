ALTER TABLE `tasks` ADD `completedAt` timestamp NULL;
--> statement-breakpoint
UPDATE `tasks` SET `completedAt` = `updatedAt` WHERE `status` = 'done' AND `completedAt` IS NULL;
--> statement-breakpoint
ALTER TABLE `taskChangeLogs` ADD `previousCompletedAt` timestamp NULL;

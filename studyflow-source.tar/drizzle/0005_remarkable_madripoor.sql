CREATE TABLE `studyNotes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`content` text NOT NULL,
	`template` enum('free','lecture','sq3r','review') NOT NULL DEFAULT 'free',
	`tags` varchar(320) NOT NULL DEFAULT '',
	`isPinned` boolean NOT NULL DEFAULT false,
	`bookId` int,
	`chapterId` int,
	`taskId` int,
	`goalId` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `studyNotes_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `taskSubtasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`taskId` int NOT NULL,
	`title` varchar(220) NOT NULL,
	`isCompleted` boolean NOT NULL DEFAULT false,
	`sortOrder` int NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `taskSubtasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `tasks` ADD `estimatedMinutes` int DEFAULT 25 NOT NULL;--> statement-breakpoint
ALTER TABLE `studyNotes` ADD CONSTRAINT `studyNotes_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `studyNotes` ADD CONSTRAINT `studyNotes_bookId_books_id_fk` FOREIGN KEY (`bookId`) REFERENCES `books`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `studyNotes` ADD CONSTRAINT `studyNotes_chapterId_bookChapters_id_fk` FOREIGN KEY (`chapterId`) REFERENCES `bookChapters`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `studyNotes` ADD CONSTRAINT `studyNotes_taskId_tasks_id_fk` FOREIGN KEY (`taskId`) REFERENCES `tasks`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `studyNotes` ADD CONSTRAINT `studyNotes_goalId_goals_id_fk` FOREIGN KEY (`goalId`) REFERENCES `goals`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `taskSubtasks` ADD CONSTRAINT `taskSubtasks_taskId_tasks_id_fk` FOREIGN KEY (`taskId`) REFERENCES `tasks`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `study_notes_user_pinned_updated_idx` ON `studyNotes` (`userId`,`isPinned`,`updatedAt`);--> statement-breakpoint
CREATE INDEX `study_notes_user_template_idx` ON `studyNotes` (`userId`,`template`);--> statement-breakpoint
CREATE INDEX `task_subtasks_task_sort_idx` ON `taskSubtasks` (`taskId`,`sortOrder`);
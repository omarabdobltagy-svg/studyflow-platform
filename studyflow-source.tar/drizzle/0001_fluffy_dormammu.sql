CREATE TABLE `aiPlans` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`prompt` text NOT NULL,
	`title` varchar(180) NOT NULL,
	`planJson` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `aiPlans_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bookChapters` (
	`id` int AUTO_INCREMENT NOT NULL,
	`bookId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`sortOrder` int NOT NULL DEFAULT 0,
	`totalPages` int NOT NULL DEFAULT 0,
	`completedPages` int NOT NULL DEFAULT 0,
	`status` enum('not_started','in_progress','completed') NOT NULL DEFAULT 'not_started',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bookChapters_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `books` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`author` varchar(140),
	`subject` varchar(100) NOT NULL DEFAULT 'دراسة',
	`coverColor` varchar(20) NOT NULL DEFAULT 'violet',
	`totalPages` int NOT NULL DEFAULT 0,
	`completedPages` int NOT NULL DEFAULT 0,
	`status` enum('planned','reading','completed') NOT NULL DEFAULT 'planned',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `books_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `calendarEvents` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`type` enum('event','study','goal') NOT NULL DEFAULT 'event',
	`startAt` timestamp NOT NULL,
	`endAt` timestamp,
	`allDay` boolean NOT NULL DEFAULT false,
	`color` varchar(20) NOT NULL DEFAULT 'violet',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `calendarEvents_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `goals` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`description` text,
	`kind` enum('short','long') NOT NULL DEFAULT 'short',
	`category` varchar(80) NOT NULL DEFAULT 'شخصي',
	`color` varchar(20) NOT NULL DEFAULT 'violet',
	`targetDate` timestamp,
	`status` enum('active','completed','paused') NOT NULL DEFAULT 'active',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `goals_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `routineCompletions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`routineItemId` int NOT NULL,
	`dateKey` varchar(10) NOT NULL,
	`completedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `routineCompletions_id` PRIMARY KEY(`id`),
	CONSTRAINT `routine_completion_once_per_day_idx` UNIQUE(`routineItemId`,`dateKey`)
);
--> statement-breakpoint
CREATE TABLE `routineItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`routineId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`durationMinutes` int NOT NULL DEFAULT 10,
	`sortOrder` int NOT NULL DEFAULT 0,
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `routineItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `routines` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`name` varchar(120) NOT NULL,
	`period` enum('morning','evening','custom') NOT NULL DEFAULT 'morning',
	`accent` varchar(20) NOT NULL DEFAULT 'amber',
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `routines_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `studySessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bookId` int NOT NULL,
	`chapterId` int,
	`step` enum('survey','question','read','recite','review') NOT NULL,
	`notes` text,
	`status` enum('active','completed') NOT NULL DEFAULT 'active',
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `studySessions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tasks` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`goalId` int,
	`bookId` int,
	`title` varchar(220) NOT NULL,
	`notes` text,
	`category` varchar(80) NOT NULL DEFAULT 'عام',
	`priority` enum('low','medium','high') NOT NULL DEFAULT 'medium',
	`status` enum('todo','done') NOT NULL DEFAULT 'todo',
	`dueAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `tasks_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE INDEX `ai_plans_user_created_idx` ON `aiPlans` (`userId`,`createdAt`);--> statement-breakpoint
CREATE INDEX `chapters_book_sort_idx` ON `bookChapters` (`bookId`,`sortOrder`);--> statement-breakpoint
CREATE INDEX `books_user_status_idx` ON `books` (`userId`,`status`);--> statement-breakpoint
CREATE INDEX `calendar_events_user_start_idx` ON `calendarEvents` (`userId`,`startAt`);--> statement-breakpoint
CREATE INDEX `goals_user_status_idx` ON `goals` (`userId`,`status`);--> statement-breakpoint
CREATE INDEX `routine_items_routine_sort_idx` ON `routineItems` (`routineId`,`sortOrder`);--> statement-breakpoint
CREATE INDEX `routines_user_active_idx` ON `routines` (`userId`,`isActive`);--> statement-breakpoint
CREATE INDEX `sessions_user_book_idx` ON `studySessions` (`userId`,`bookId`);--> statement-breakpoint
CREATE INDEX `tasks_user_status_due_idx` ON `tasks` (`userId`,`status`,`dueAt`);--> statement-breakpoint
CREATE INDEX `tasks_goal_idx` ON `tasks` (`goalId`);
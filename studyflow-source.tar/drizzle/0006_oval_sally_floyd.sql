CREATE TABLE `studentProfiles` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`studentName` varchar(120) NOT NULL,
	`educationSystem` enum('baccalaureate','general_secondary','other') NOT NULL,
	`gradeYear` varchar(40) NOT NULL,
	`track` varchar(100) NOT NULL,
	`subjectsJson` text NOT NULL,
	`teacherSelectionsJson` text NOT NULL,
	`backlogJson` text NOT NULL,
	`obstacle` varchar(600) NOT NULL,
	`completedAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `studentProfiles_id` PRIMARY KEY(`id`),
	CONSTRAINT `studentProfiles_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
ALTER TABLE `goals` ADD `parentGoalId` int;--> statement-breakpoint
ALTER TABLE `goals` ADD `sortOrder` int DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `studentProfiles` ADD CONSTRAINT `studentProfiles_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `student_profiles_user_idx` ON `studentProfiles` (`userId`);--> statement-breakpoint
ALTER TABLE `goals` ADD CONSTRAINT `goals_parent_goal_fk` FOREIGN KEY (`parentGoalId`) REFERENCES `goals`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `goals_user_parent_idx` ON `goals` (`userId`,`parentGoalId`);
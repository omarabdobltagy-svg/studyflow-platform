CREATE TABLE `libraryAttachments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`bookId` int NOT NULL,
	`chapterId` int,
	`fileName` varchar(255) NOT NULL,
	`fileKey` varchar(512) NOT NULL,
	`fileUrl` text NOT NULL,
	`mimeType` varchar(160) NOT NULL,
	`sizeBytes` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `libraryAttachments_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reminderNotifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`title` varchar(180) NOT NULL,
	`content` text NOT NULL,
	`kind` enum('task','event','routine') NOT NULL,
	`sourceId` int,
	`scheduledFor` timestamp NOT NULL,
	`deliveredAt` timestamp NOT NULL DEFAULT (now()),
	`readAt` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `reminderNotifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `reminderSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`enabled` boolean NOT NULL DEFAULT false,
	`dailyTime` varchar(5) NOT NULL DEFAULT '08:00',
	`timezone` varchar(80) NOT NULL DEFAULT 'UTC',
	`scheduleCronTaskUid` varchar(65),
	`nextExecutionAt` timestamp,
	`lastDeliveredDate` varchar(10),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `reminderSettings_id` PRIMARY KEY(`id`),
	CONSTRAINT `reminderSettings_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `taskChangeLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`taskId` int NOT NULL,
	`previousStatus` enum('todo','done') NOT NULL,
	`nextStatus` enum('todo','done') NOT NULL,
	`expiresAt` timestamp NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `taskChangeLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `bookChapters` ADD `notes` text;--> statement-breakpoint
ALTER TABLE `books` ADD `notes` text;--> statement-breakpoint
ALTER TABLE `libraryAttachments` ADD CONSTRAINT `libraryAttachments_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `libraryAttachments` ADD CONSTRAINT `libraryAttachments_bookId_books_id_fk` FOREIGN KEY (`bookId`) REFERENCES `books`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `libraryAttachments` ADD CONSTRAINT `libraryAttachments_chapterId_bookChapters_id_fk` FOREIGN KEY (`chapterId`) REFERENCES `bookChapters`(`id`) ON DELETE set null ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `reminderNotifications` ADD CONSTRAINT `reminderNotifications_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `reminderSettings` ADD CONSTRAINT `reminderSettings_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `taskChangeLogs` ADD CONSTRAINT `taskChangeLogs_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `taskChangeLogs` ADD CONSTRAINT `taskChangeLogs_taskId_tasks_id_fk` FOREIGN KEY (`taskId`) REFERENCES `tasks`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `attachments_user_book_idx` ON `libraryAttachments` (`userId`,`bookId`);--> statement-breakpoint
CREATE INDEX `attachments_chapter_idx` ON `libraryAttachments` (`chapterId`);--> statement-breakpoint
CREATE INDEX `reminder_notifications_user_read_idx` ON `reminderNotifications` (`userId`,`readAt`);--> statement-breakpoint
CREATE INDEX `reminder_schedule_uid_idx` ON `reminderSettings` (`scheduleCronTaskUid`);--> statement-breakpoint
CREATE INDEX `task_changes_user_created_idx` ON `taskChangeLogs` (`userId`,`createdAt`);
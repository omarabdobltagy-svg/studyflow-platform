import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Books from "@/pages/Books";
import Calendar from "@/pages/Calendar";
import Goals from "@/pages/Goals";
import NotFound from "@/pages/NotFound";
import Onboarding from "@/pages/Onboarding";
import Planner from "@/pages/Planner";
import Reminders from "@/pages/Reminders";
import Routines from "@/pages/Routines";
import Study from "@/pages/Study";
import Tasks from "@/pages/Tasks";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Assistant from "./pages/Assistant";
import Analytics from "./pages/Analytics";

function Router() {
  // make sure to consider if you need authentication for certain routes
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/tasks"} component={Tasks} />
      <Route path={"/goals"} component={Goals} />
      <Route path={"/books/:id"} component={Books} />
      <Route path={"/books"} component={Books} />
      <Route path={"/study"} component={Study} />
      <Route path={"/routines"} component={Routines} />
      <Route path={"/calendar"} component={Calendar} />
      <Route path={"/planner"} component={Planner} />
      <Route path={"/reminders"} component={Reminders} />
      <Route path={"/assistant"} component={Assistant} />
      <Route path={"/analytics"} component={Analytics} />
      <Route path={"/onboarding"} component={Onboarding} />
      <Route path={"/settings"} component={() => <Onboarding editMode />} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" switchable>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;

import { AlertCircle, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function QueryErrorNotice({ onRetry, label = "تعذّر تحميل هذه البيانات الآن." }: { onRetry: () => void; label?: string }) {
  return (
    <div role="alert" className="my-5 flex flex-col items-center justify-center rounded-2xl border border-rose-200 bg-rose-50/70 px-5 py-8 text-center text-rose-950 dark:border-rose-900/70 dark:bg-rose-950/25 dark:text-rose-100">
      <AlertCircle className="mb-3 size-6 text-rose-600 dark:text-rose-300" />
      <p className="font-semibold">{label}</p>
      <p className="mt-1 text-sm text-rose-800/75 dark:text-rose-100/75">تحقق من الاتصال أو أعد المحاولة خلال لحظات.</p>
      <Button variant="outline" onClick={onRetry} className="mt-4 gap-2 border-rose-200 bg-card text-rose-800 hover:bg-rose-100 dark:border-rose-900 dark:text-rose-200 dark:hover:bg-rose-950/40">
        <RefreshCw className="size-4" />إعادة المحاولة
      </Button>
    </div>
  );
}

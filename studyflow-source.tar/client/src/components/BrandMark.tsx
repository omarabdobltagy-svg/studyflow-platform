export default function BrandMark({ className = "size-5" }: { className?: string }) {
  return (
    <svg
      aria-hidden="true"
      viewBox="0 0 40 40"
      fill="none"
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M11 28.5C7.8 24.6 7.8 17.2 11.4 12.9C14.1 9.7 18.2 8.6 21.6 10.1"
        stroke="currentColor"
        strokeWidth="2.6"
        strokeLinecap="round"
      />
      <path
        d="M29 11.5C32.2 15.4 32.2 22.8 28.6 27.1C25.9 30.3 21.8 31.4 18.4 29.9"
        stroke="currentColor"
        strokeWidth="2.6"
        strokeLinecap="round"
      />
      <path
        d="M13.5 20H26.5"
        stroke="currentColor"
        strokeWidth="2.6"
        strokeLinecap="round"
        opacity=".65"
      />
      <circle cx="20" cy="20" r="4.2" fill="currentColor" />
    </svg>
  );
}

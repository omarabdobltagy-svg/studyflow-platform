import { Button } from "@/components/ui/button";
import { buildPlanFollowUpDocument, printPlanAsPdf, type ExportPlan } from "@/lib/planExport";
import { Clipboard, FileDown, Loader2 } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function PlanExportActions({ plan, studentName }: { plan: ExportPlan; studentName?: string }) {
  const [copying, setCopying] = useState(false);
  const copyDocument = async () => {
    setCopying(true);
    try {
      await navigator.clipboard.writeText(buildPlanFollowUpDocument(plan, studentName));
      toast.success("تم نسخ مستند المتابعة. يمكنك لصقه مباشرة في Google Docs.");
    } catch {
      toast.error("تعذّر النسخ التلقائي. جرّب زر الطباعة ثم اختر حفظ PDF.");
    } finally { setCopying(false); }
  };
  const openGoogleDocs = async () => {
    const tab = window.open("https://docs.new", "_blank", "noopener,noreferrer");
    await copyDocument();
    if (!tab) toast("تم نسخ المستند. افتح Google Docs والصقه يدويًا إذا منع المتصفح النافذة الجديدة.");
  };
  return <div className="no-print flex flex-wrap gap-2"><Button type="button" variant="outline" onClick={printPlanAsPdf} className="pressable rounded-xl"><FileDown className="size-4" />تنزيل PDF</Button><Button type="button" variant="outline" onClick={copyDocument} disabled={copying} className="pressable rounded-xl">{copying ? <Loader2 className="size-4 animate-spin" /> : <Clipboard className="size-4" />}نسخ المستند</Button><Button type="button" variant="outline" onClick={openGoogleDocs} disabled={copying} className="pressable rounded-xl">فتح Google Docs</Button></div>;
}

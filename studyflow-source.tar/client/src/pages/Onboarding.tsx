import DashboardLayout from "@/components/DashboardLayout";
import QueryErrorNotice from "@/components/QueryErrorNotice";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { ArrowRight, ArrowLeft, Check, ExternalLink, Loader2, Search, Sparkles, UserRound } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const coreSubjects = ["العربي", "الإنجليزي", "التاريخ"];
const generalTracks = ["علمي علوم", "علمي رياضة", "أدبي", "مسار آخر"];
const baccalaureateTracks = ["الطب وعلوم الحياة", "الهندسة وعلوم الحاسب", "مسار آخر"];
const steps = ["بياناتك", "مسارك", "مدرسوك", "التراكم", "طاقتك"];

type FormState = {
  studentName: string;
  educationSystem: "baccalaureate" | "general_secondary" | "other";
  gradeYear: string;
  track: string;
  subjects: string[];
  teacherSelections: Record<string, string>;
  backlog: Record<string, number>;
  obstacle: string;
};

const emptyForm: FormState = { studentName: "", educationSystem: "general_secondary", gradeYear: "", track: "", subjects: coreSubjects, teacherSelections: {}, backlog: {}, obstacle: "" };

export default function Onboarding({ editMode = false }: { editMode?: boolean }) {
  const [, setLocation] = useLocation();
  const profile = trpc.studentProfile.get.useQuery();
  const save = trpc.studentProfile.save.useMutation({ onSuccess: () => { toast.success(editMode ? "تم تحديث ملفك الدراسي." : "تم حفظ ملفك الدراسي. سنبني خططك بناءً عليه."); setLocation("/"); }, onError: error => toast.error(error.message) });
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<FormState>(emptyForm);
  useEffect(() => {
    if (profile.data) setForm({ studentName: profile.data.studentName, educationSystem: profile.data.educationSystem, gradeYear: profile.data.gradeYear, track: profile.data.track, subjects: profile.data.subjects, teacherSelections: profile.data.teacherSelections, backlog: profile.data.backlog, obstacle: profile.data.obstacle });
  }, [profile.data]);
  const isCustomCurriculum = form.educationSystem === "other" || form.track === "مسار آخر";
  const specialtySubjects = useMemo(() => {
    if (isCustomCurriculum) return [];
    if (form.educationSystem === "baccalaureate") {
      return form.track === "الطب وعلوم الحياة" ? ["الأحياء المتقدم", "الكيمياء المتقدم"]
        : form.track === "الهندسة وعلوم الحاسب" ? ["الرياضيات المتقدم", "الفيزياء المتقدم"] : [];
    }
    return form.track === "علمي علوم" ? ["الأحياء"] : form.track === "علمي رياضة" ? ["الرياضيات"] : form.track === "أدبي" ? ["الجغرافيا"] : [];
  }, [form.educationSystem, form.track, isCustomCurriculum]);
  const allSubjects = useMemo(() => isCustomCurriculum
    ? Array.from(new Set(form.subjects.map(subject => subject.trim()).filter(Boolean)))
    : [...coreSubjects, ...specialtySubjects], [form.subjects, isCustomCurriculum, specialtySubjects]);
  const update = <K extends keyof FormState>(key: K, value: FormState[K]) => setForm(current => ({ ...current, [key]: value }));
  const canContinue = step === 0 ? form.studentName.trim().length >= 2 && form.gradeYear.trim().length > 0 : step === 1 ? form.track.length > 0 && (!isCustomCurriculum || allSubjects.length > 0) : step === 4 ? form.obstacle.trim().length >= 2 : true;
  const next = () => { if (!canContinue) return toast.error(step === 0 ? "اكتب اسمك وسنتك الدراسية أولًا." : step === 1 ? "اختر مسارك الدراسي." : "اكتب ما الذي يعطلك حتى نساعدك بواقعية."); setStep(current => Math.min(4, current + 1)); };
  const previous = () => setStep(current => Math.max(0, current - 1));
  const submit = () => {
    if (allSubjects.length === 0) return toast.error("أضف مادة واحدة على الأقل قبل الحفظ.");
    save.mutate({ ...form, subjects: allSubjects });
  };
  const currentSteps = steps;
  return <DashboardLayout title={editMode ? "الملف الدراسي" : "نتعرف عليك أولًا"} description={editMode ? "حدّث بياناتك وموادك ومدرسيك والتراكم الدراسي؛ ستُستخدم التغييرات في التخطيط القادم." : "بضع إجابات قصيرة تجعل StudyFlow يفهم مسارك وطاقتك قبل أن يقترح عليك أي خطة."} action={<div className="hidden items-center gap-2 rounded-2xl bg-secondary px-3 py-2 text-xs font-semibold text-primary sm:flex"><Sparkles className="size-4" />ملفك الدراسي</div>}>
    {editMode && profile.isError && <QueryErrorNotice onRetry={() => void profile.refetch()} label="تعذّر تحميل الملف الحالي. لن نسمح بحفظ بيانات فارغة فوق بياناتك." />}
    {editMode && profile.isLoading ? <div className="app-card mx-auto max-w-4xl p-8 text-center text-sm text-muted-foreground" role="status">نحمّل ملفك الدراسي قبل إتاحة التعديل…</div> : editMode && !profile.isSuccess ? null : editMode && !profile.data ? <div className="app-card mx-auto max-w-4xl p-8 text-center text-sm text-muted-foreground">لا يوجد ملف دراسي محفوظ بعد. افتح مسار البداية لإعداده.</div> : <>
    <section className="relative mx-auto max-w-4xl overflow-hidden rounded-[2rem] bg-primary p-6 text-primary-foreground shadow-2xl shadow-primary/15 sm:p-9">
      <div className="onboarding-orb onboarding-orb-one" /><div className="onboarding-orb onboarding-orb-two" />
      <div className="relative"><div className="mb-7 flex items-center justify-between gap-4"><div><p className="eyebrow text-primary-foreground/65">{editMode ? "إدارة بياناتك" : "رحلة البداية"}</p><h2 className="mt-2 text-2xl font-bold sm:text-3xl">{editMode ? "حدّث مسارك الدراسي." : "خلّينا نبني المسار المناسب لك."}</h2></div><span className="flex size-12 items-center justify-center rounded-2xl bg-white/10"><UserRound className="size-6" /></span></div><Progress value={((step + 1) / steps.length) * 100} className="h-2 bg-white/15 [&>div]:bg-violet-200" /><div className="mt-3 flex justify-between text-[11px] text-primary-foreground/65">{currentSteps.map((item, index) => <span key={item} className={index <= step ? "font-bold text-white" : ""}>{item}</span>)}</div></div>
    </section>
    <section className="mx-auto mt-5 max-w-4xl app-card overflow-hidden"><div className="border-b border-border/70 bg-muted/25 px-5 py-5 sm:px-7"><p className="eyebrow">الخطوة {step + 1} من {currentSteps.length}</p><h1 className="mt-1 text-xl font-bold">{steps[step]}</h1></div><div className="min-h-[360px] p-5 sm:p-7">{step === 0 && <IdentityStep form={form} update={update} />}{step === 1 && <TrackStep form={form} update={update} specialty={specialtySubjects.join("، ")} tracks={form.educationSystem === "baccalaureate" ? baccalaureateTracks : form.educationSystem === "other" ? ["مسار آخر"] : generalTracks} customSubjects={isCustomCurriculum ? allSubjects : []} />}{step === 2 && <TeacherStep subjects={allSubjects} form={form} update={update} />}{step === 3 && <BacklogStep subjects={allSubjects} form={form} update={update} />}{step === 4 && <MotivationStep form={form} update={update} />}</div><div className="flex flex-col-reverse gap-3 border-t border-border/70 bg-muted/20 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-7"><Button type="button" variant="ghost" onClick={previous} disabled={step === 0 || save.isPending} className="rounded-xl"> <ArrowRight className="size-4" />رجوع</Button>{step < 4 ? <Button type="button" onClick={next} className="pressable rounded-xl bg-primary">التالي <ArrowLeft className="size-4" /></Button> : <Button type="button" onClick={submit} disabled={save.isPending || profile.isLoading || (editMode && !profile.isSuccess)} className="pressable rounded-xl bg-primary">{save.isPending ? <><Loader2 className="size-4 animate-spin" />نحفظ ملفك...</> : <><Check className="size-4" />{editMode ? "حفظ التغييرات" : "ابدأ مساري الذكي"}</>}</Button>}</div></section>
    </>}
  </DashboardLayout>;
}

function IdentityStep({ form, update }: { form: FormState; update: <K extends keyof FormState>(key: K, value: FormState[K]) => void }) { return <div className="grid gap-5 sm:grid-cols-2"><div><label className="mb-2 block text-sm font-semibold">ما اسمك؟</label><Input autoFocus value={form.studentName} onChange={event => update("studentName", event.target.value)} placeholder="مثال: أحمد" className="h-12 rounded-xl bg-background" /></div><div><label className="mb-2 block text-sm font-semibold">نظامك الدراسي</label><Select value={form.educationSystem} onValueChange={(value: FormState["educationSystem"]) => { update("educationSystem", value); update("track", value === "other" ? "مسار آخر" : ""); }}><SelectTrigger className="h-12 rounded-xl bg-background"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="general_secondary">ثانوية عامة</SelectItem><SelectItem value="baccalaureate">بكالوريا</SelectItem><SelectItem value="other">نظام آخر</SelectItem></SelectContent></Select></div><div><label className="mb-2 block text-sm font-semibold">في سنة/صف كام؟</label><Input value={form.gradeYear} onChange={event => update("gradeYear", event.target.value)} placeholder="مثال: الصف الثالث الثانوي" className="h-12 rounded-xl bg-background" /></div><div className="rounded-2xl bg-secondary/55 p-4 text-sm leading-7 text-muted-foreground">لن نضع خطة عشوائية. إجاباتك تحدد المواد، حجم التراكم، وطريقة العودة المناسبة لطاقة يومك.</div></div>; }
function TrackStep({ form, update, specialty, tracks, customSubjects }: { form: FormState; update: <K extends keyof FormState>(key: K, value: FormState[K]) => void; specialty: string; tracks: string[]; customSubjects: string[] }) {
  const [newSubject, setNewSubject] = useState("");
  const customMode = form.educationSystem === "other" || form.track === "مسار آخر";
  const addSubject = () => {
    const subject = newSubject.trim();
    if (!subject) return;
    if (customSubjects.some(item => item.toLocaleLowerCase() === subject.toLocaleLowerCase())) return toast.error("هذه المادة موجودة بالفعل.");
    update("subjects", [...customSubjects, subject]);
    setNewSubject("");
  };
  return <div>
    <p className="text-sm leading-7 text-muted-foreground">اختر مسارك حتى نضيف المواد المناسبة. يمكنك تحديد المواد بنفسك عند اختيار نظام أو مسار آخر.</p>
    <div className="mt-5 grid gap-3 sm:grid-cols-2">{tracks.map((track: string) => <button type="button" key={track} onClick={() => update("track", track)} className={`pressable rounded-2xl border p-4 text-right transition ${form.track === track ? "border-primary bg-secondary text-primary shadow-sm" : "border-border bg-card hover:border-primary/30"}`}><span className="block font-bold">{track}</span><span className="mt-1 block text-xs text-muted-foreground">{track === "مسار آخر" ? "أضف موادك يدويًا" : form.educationSystem === "baccalaureate" ? (track === "الطب وعلوم الحياة" ? "أحياء وكيمياء متقدمان" : "رياضيات وفيزياء متقدمان") : track === "علمي علوم" ? "الأحياء" : track === "علمي رياضة" ? "الرياضيات" : track === "أدبي" ? "الجغرافيا" : "مواد يحددها الطالب"}</span></button>)}</div>
    {customMode ? <div className="mt-5 rounded-2xl border border-primary/15 bg-secondary/20 p-4">
      <h3 className="font-bold">موادك الدراسية</h3><p className="mt-1 text-xs leading-6 text-muted-foreground">أضف المواد التي تدرسها فعلًا؛ ستظهر في اختيار المدرسين وتسجيل التراكم.</p>
      <div className="mt-3 flex flex-col gap-2 sm:flex-row"><Input value={newSubject} onChange={event => setNewSubject(event.target.value)} onKeyDown={event => { if (event.key === "Enter") { event.preventDefault(); addSubject(); } }} placeholder="اسم المادة" className="h-11 rounded-xl bg-background" /><Button type="button" onClick={addSubject} className="rounded-xl">إضافة مادة</Button></div>
      <div className="mt-3 flex flex-wrap gap-2">{customSubjects.map(subject => <span key={subject} className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-3 py-2 text-sm"><span>{subject}</span><button type="button" onClick={() => update("subjects", customSubjects.filter(item => item !== subject))} className="text-muted-foreground hover:text-destructive" aria-label={`حذف مادة ${subject}`}>×</button></span>)}</div>
      {!customSubjects.length && <p className="mt-3 text-xs text-destructive">أضف مادة واحدة على الأقل للمتابعة.</p>}
    </div> : <p className="mt-5 rounded-xl bg-muted/55 p-3 text-xs text-muted-foreground">المواد المضافة تلقائيًا: {coreSubjects.join("، ")}{specialty ? `، ${specialty}` : ""}.</p>}
  </div>;
}
function TeacherStep({ subjects, form, update }: { subjects: string[]; form: FormState; update: <K extends keyof FormState>(key: K, value: FormState[K]) => void }) { const [subject, setSubject] = useState(subjects[0] || ""); const research = trpc.teachers.research.useMutation(); return <div><p className="text-sm leading-7 text-muted-foreground">ابحث عن أسماء متداولة في YouTube ثم اختر ما يناسبك. النتائج تأتي من المصدر، ويمكنك دائمًا كتابة اسم مدرس غير موجود يدويًا.</p><div className="mt-5 grid gap-5 lg:grid-cols-[1fr_.9fr]"><div className="space-y-4">{subjects.map(item => <div key={item}><label className="mb-2 block text-sm font-semibold">مدرس {item}</label><Input value={form.teacherSelections[item] || ""} onFocus={() => setSubject(item)} onChange={event => update("teacherSelections", { ...form.teacherSelections, [item]: event.target.value })} placeholder="اكتب الاسم أو ابحث عنه" className="h-11 rounded-xl bg-background" /></div>)}</div><div className="rounded-2xl border border-primary/15 bg-secondary/35 p-4"><div className="flex items-center justify-between gap-3"><div><p className="font-bold text-primary">اقتراحات من YouTube</p><p className="mt-1 text-xs text-muted-foreground">نتائج مقترحة من YouTube للمادة المختارة؛ راجع القناة قبل الاختيار.</p></div><Search className="size-5 text-primary" /></div><Select value={subject} onValueChange={setSubject}><SelectTrigger className="mt-4 h-10 rounded-xl bg-background"><SelectValue /></SelectTrigger><SelectContent>{subjects.map(item => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select><Button type="button" onClick={() => research.mutate({ subject, track: form.track })} disabled={research.isPending} className="mt-3 w-full rounded-xl bg-primary">{research.isPending ? <><Loader2 className="size-4 animate-spin" />نبحث في المصادر...</> : <><Search className="size-4" />ابحث عن المدرسين</>}</Button>{research.data?.candidates?.length ? <div className="mt-4 space-y-2">{research.data.candidates.map(candidate => <button type="button" key={`${candidate.name}-${candidate.url}`} onClick={() => update("teacherSelections", { ...form.teacherSelections, [subject]: candidate.name })} className="flex w-full items-center justify-between gap-2 rounded-xl border border-border bg-card p-3 text-right text-sm hover:border-primary/35"><span className="font-semibold">{candidate.name}</span>{candidate.url && <a href={candidate.url} target="_blank" rel="noreferrer" onClick={event => event.stopPropagation()} aria-label={`فتح مصدر ${candidate.name}`}><ExternalLink className="size-3.5 text-muted-foreground" /></a>}</button>)}</div> : research.isSuccess ? <p className="mt-4 text-xs leading-6 text-muted-foreground">لم تصل نتائج واضحة لهذه المادة الآن. اكتب الاسم يدويًا أو حاول بصيغة أخرى.</p> : null}</div></div></div>; }
function BacklogStep({ subjects, form, update }: { subjects: string[]; form: FormState; update: <K extends keyof FormState>(key: K, value: FormState[K]) => void }) { return <div><p className="text-sm leading-7 text-muted-foreground">كم محاضرة متراكمة لديك؟ يمكنك تركها صفرًا. اضغط داخل الرقم وسيتم تحديده تلقائيًا لتكتب رقمًا جديدًا بسهولة.</p><div className="mt-5 grid gap-3 sm:grid-cols-2">{subjects.map(subject => <label key={subject} className="flex items-center justify-between gap-4 rounded-2xl border border-border bg-muted/20 p-4"><span className="font-semibold">{subject}</span><Input type="number" min={0} max={999} inputMode="numeric" value={form.backlog[subject] ?? 0} onFocus={event => event.currentTarget.select()} onChange={event => update("backlog", { ...form.backlog, [subject]: event.target.value === "" ? 0 : Number(event.target.value) })} className="h-11 w-24 rounded-xl bg-background text-center" /></label>)}</div></div>; }
function MotivationStep({ form, update }: { form: FormState; update: <K extends keyof FormState>(key: K, value: FormState[K]) => void }) { return <div><p className="text-sm leading-7 text-muted-foreground">ما أكبر عائق تواجهه الآن؟ اكتبها بصراحة. سنستخدمها لصناعة خطة عودة مرنة، لا لاتهامك أو الضغط عليك.</p><Textarea autoFocus value={form.obstacle} onChange={event => update("obstacle", event.target.value)} placeholder="مثال: أشعر بالكسل وقلة الطاقة، وأتوه عندما تتراكم المحاضرات..." className="mt-5 min-h-36 rounded-2xl bg-background p-4 leading-8" /><div className="mt-4 rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm leading-7 text-amber-950 dark:border-amber-900/70 dark:bg-amber-950/35 dark:text-amber-100">إذا قلت: «ليس لدي طاقة»، سنبدأ بجلسات قصيرة جدًا ونبني الالتزام تدريجيًا بدل خطة ضخمة يصعب البدء بها.</div></div>; }

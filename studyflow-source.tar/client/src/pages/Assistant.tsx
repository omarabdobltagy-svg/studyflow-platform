import DashboardLayout from "@/components/DashboardLayout";
import { AIChatBox, type Message } from "@/components/AIChatBox";
import { Badge } from "@/components/ui/badge";
import { trpc } from "@/lib/trpc";
import { BrainCircuit, ShieldCheck, Sparkles, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useEffect, useState } from "react";
import { toast } from "sonner";

const suggestions = [
  "أنا متراكم ومش قادر أبدأ، ساعدني بخطوة صغيرة الآن.",
  "قسّم لي مذاكرة مادة واحدة اليوم حسب طاقتي.",
  "كيف أرجع لروتيني بعد انقطاع بدون جلد ذات؟",
];

const CHAT_STORAGE_KEY = "studyflow.assistant.chat.v1";

function loadChat(): Message[] {
  try {
    const raw = window.sessionStorage.getItem(CHAT_STORAGE_KEY);
    if (!raw) return [];
    const value = JSON.parse(raw);
    if (!Array.isArray(value)) return [];
    return value.filter((message): message is Message =>
      message && ["user", "assistant"].includes(message.role) &&
      typeof message.content === "string" && message.content.length <= 6_000
    ).slice(-40);
  } catch {
    return [];
  }
}

export default function Assistant() {
  const [messages, setMessages] = useState<Message[]>(loadChat);
  useEffect(() => {
    try {
      window.sessionStorage.setItem(CHAT_STORAGE_KEY, JSON.stringify(messages.slice(-40)));
    } catch {
      toast.error("تعذّر حفظ المحادثة في جلسة المتصفح الحالية.");
    }
  }, [messages]);
  const chat = trpc.ai.chat.useMutation({
    onSuccess: result => setMessages(current => [...current, { role: "assistant", content: result.content }]),
    onError: error => {
      setMessages(current => current.slice(0, -1));
      toast.error(error.message || "تعذّر الرد الآن");
    },
  });

  const sendMessage = (content: string) => {
    const next = [...messages, { role: "user" as const, content }].slice(-40);
    setMessages(next);
    // The API accepts at most 20 turns. Send the newest context window only.
    chat.mutate({ messages: next.filter((message): message is Extract<Message, { role: "user" | "assistant" }> => message.role !== "system").slice(-20) });
  };

  const clearConversation = () => {
    if (chat.isPending) return;
    setMessages([]);
    try { window.sessionStorage.removeItem(CHAT_STORAGE_KEY); } catch { /* storage may be disabled */ }
    toast.success("تم مسح المحادثة من جلسة المتصفح الحالية.");
  };

  return (
    <DashboardLayout title="المساعد الذكي" description="مساحة حوار عربية تساعدك على العودة، ترتيب الأولويات، وتحويل التشتت إلى خطوة قابلة للتنفيذ.">
      <section className="relative mb-6 overflow-hidden rounded-[1.6rem] bg-primary px-5 py-7 text-primary-foreground shadow-[0_28px_70px_-38px_rgba(45,37,92,.95)] sm:px-8">
        <div className="absolute -left-12 -top-16 size-56 rounded-full bg-violet-300/20 blur-3xl" />
        <div className="absolute bottom-0 right-1/3 size-36 rounded-full bg-amber-200/15 blur-3xl" />
        <div className="relative flex flex-col gap-5 md:flex-row md:items-end md:justify-between">
          <div>
            <div className="mb-3 flex items-center gap-2 text-sm text-primary-foreground/75"><span className="flex size-9 items-center justify-center rounded-xl bg-white/12"><Sparkles className="size-4" /></span>رفيقك في مسار التعلّم</div>
            <h2 className="text-2xl font-bold tracking-tight sm:text-3xl">اسأل بدون تعقيد، وابدأ بخطوة حقيقية.</h2>
            <p className="mt-3 max-w-2xl text-sm leading-7 text-primary-foreground/70">يستخدم ملفك الدراسي والمهام والأهداف والكتب والروتين والمواعيد المسجلة لتخصيص الرد، لكنه لا ينشئ بيانات أو يغيّر خطتك من تلقاء نفسه.</p>
          </div>
          <Badge className="w-fit gap-2 rounded-full border border-white/15 bg-white/10 px-3 py-2 text-primary-foreground"><ShieldCheck className="size-3.5" />اقتراحات آمنة بموافقتك</Badge>
        </div>
      </section>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <p className="text-xs text-muted-foreground">تُحفظ الرسائل مؤقتًا في جلسة المتصفح على هذا الجهاز، وتُرسل الرسائل مع سياقك الدراسي إلى مزود نموذج الذكاء الاصطناعي لتوليد الرد. لا تُزامن المحادثة بين الأجهزة.</p>
        <Button type="button" variant="outline" size="sm" disabled={!messages.length || chat.isPending} onClick={clearConversation} className="gap-2 rounded-xl">
          <Trash2 className="size-3.5" />مسح المحادثة
        </Button>
      </div>
      <div className="grid gap-6 xl:grid-cols-[minmax(0,1fr)_280px]">
        <AIChatBox
          messages={messages}
          onSendMessage={sendMessage}
          isLoading={chat.isPending}
          height="min(68vh, 680px)"
          placeholder="اكتب سؤالك أو استخدم الميكروفون..."
          emptyStateMessage="أنا جاهز أساعدك في أول خطوة."
          suggestedPrompts={suggestions}
        />
        <aside className="app-card h-fit p-5">
          <div className="mb-4 flex items-center gap-3"><span className="flex size-10 items-center justify-center rounded-xl bg-secondary text-primary"><BrainCircuit className="size-5" /></span><div><p className="font-bold">كيف تستخدمه؟</p><p className="text-xs text-muted-foreground">ثلاث قواعد بسيطة</p></div></div>
          <ol className="space-y-4 text-sm leading-7 text-muted-foreground"><li><b className="text-foreground">01.</b> اذكر المادة والوقت والطاقة المتاحة.</li><li><b className="text-foreground">02.</b> اطلب خطوة واحدة بدل خطة ضخمة.</li><li><b className="text-foreground">03.</b> راجع اقتراحه ووافق قبل أي إنشاء.</li></ol>
          <p className="mt-5 rounded-xl bg-muted/50 p-3 text-xs leading-6 text-muted-foreground">الصوت يتحول إلى نص داخل المتصفح مع طلب إذن الميكروفون، ويمكنك تعديل النص قبل الإرسال.</p>
        </aside>
      </div>
    </DashboardLayout>
  );
}

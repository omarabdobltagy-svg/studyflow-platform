import DashboardLayout from "@/components/DashboardLayout";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { trpc } from "@/lib/trpc";
import QueryErrorNotice from "@/components/QueryErrorNotice";
import { BarChart3, CheckCircle2, Clock3, Target } from "lucide-react";

const periodLabels = { daily: "اليوم", weekly: "هذا الأسبوع", monthly: "هذا الشهر" } as const;

export default function Analytics() {
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC";
  const analytics = trpc.dashboard.analytics.useQuery({ timeZone });
  const data = analytics.data;
  return <DashboardLayout title="لوحة التقدم" description="اقرأ نشاطك كما هو: إنجاز المهام حسب المادة والفترة، بدون نسب مصطنعة أو ادعاء بقياس الإتقان.">
    {analytics.isError && <QueryErrorNotice onRetry={() => void analytics.refetch()} label="تعذّر تحميل مؤشرات التقدم." />}
    {analytics.isLoading ? <div className="grid gap-4 md:grid-cols-3">{[1, 2, 3].map(item => <div key={item} className="h-32 animate-pulse rounded-2xl bg-muted" />)}</div> : data ? <>
      <section className="mb-6 grid gap-4 md:grid-cols-3">
        {(Object.entries(data.periods) as Array<[keyof typeof periodLabels, typeof data.periods.daily]>).map(([key, period]) => <div key={key} className="app-card relative overflow-hidden p-5"><div className="relative flex items-start justify-between"><span className="flex size-10 items-center justify-center rounded-xl bg-secondary text-primary">{key === "daily" ? <Clock3 className="size-5" /> : key === "weekly" ? <BarChart3 className="size-5" /> : <Target className="size-5" />}</span><span className="num text-3xl font-semibold">{period.completed}</span></div><p className="mt-5 font-bold">{periodLabels[key]}</p><p className="mt-1 text-xs text-muted-foreground">مهمة أُنجزت خلال هذه الفترة</p></div>)}
      </section>
      <section className="app-card overflow-hidden">
        <div className="flex flex-col gap-3 border-b border-border/70 px-5 py-5 sm:flex-row sm:items-center sm:justify-between sm:px-6"><div><div className="flex items-center gap-3"><span className="flex size-9 items-center justify-center rounded-xl bg-secondary text-primary"><CheckCircle2 className="size-5" /></span><h2 className="font-bold">التقدم حسب المادة</h2></div><p className="mt-2 text-xs leading-6 text-muted-foreground">المادة هنا مأخوذة من تصنيف المهمة. عدّل التصنيف من صفحة المهام لتحصل على قراءة أدق.</p></div><Badge variant="secondary" className="w-fit rounded-full">نشاط الخطة</Badge></div>
        <div className="divide-y divide-border/60">{data?.subjects.length ? data.subjects.map(subject => <div key={subject.name} className="px-5 py-5 sm:px-6"><div className="mb-3 flex items-center justify-between gap-3"><div className="min-w-0"><p className="truncate font-semibold">{subject.name}</p><p className="mt-1 text-xs text-muted-foreground">{subject.completed} مكتملة · {subject.overdue} متأخرة · {subject.total} إجمالي</p></div><span className="num text-sm font-semibold text-primary">{subject.rate}%</span></div><Progress value={subject.rate} className="h-2 bg-muted" /></div>) : <div className="px-6 py-14 text-center text-sm text-muted-foreground">لا توجد مهام مصنفة بعد. ابدأ بإضافة مهمة لمادة.</div>}</div>
      </section>
      <p className="mt-4 rounded-2xl border border-amber-200/70 bg-amber-50/70 p-4 text-xs leading-6 text-amber-900 dark:border-amber-900/70 dark:bg-amber-950/35 dark:text-amber-100">{data?.disclaimer}</p>
    </> : !analytics.isError ? <div className="app-card p-6 text-center text-sm text-muted-foreground">لا توجد بيانات كافية لعرض التقدم الآن.</div> : null}
  </DashboardLayout>;
}

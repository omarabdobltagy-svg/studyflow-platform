import DashboardLayout from "@/components/DashboardLayout";
import QueryErrorNotice from "@/components/QueryErrorNotice";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { trpc } from "@/lib/trpc";
import { cn } from "@/lib/utils";
import { BookOpenText, Check, CircleHelp, Eye, Mic2, RefreshCcw, Search, Sparkles, Timer, Play, Square } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";

const steps = [
  { id: "survey", title: "مسح", hint: "ألقِ نظرة على العناوين والرسوم والأفكار الكبرى قبل الغوص في التفاصيل.", icon: Eye, tint: "bg-violet-100 text-violet-700 dark:bg-violet-950/50 dark:text-violet-200" },
  { id: "question", title: "تساؤل", hint: "حوّل العناوين إلى أسئلة؛ ما الذي تحتاج إلى فهمه من هذا الجزء؟", icon: CircleHelp, tint: "bg-amber-100 text-amber-700 dark:bg-amber-950/50 dark:text-amber-200" },
  { id: "read", title: "قراءة", hint: "اقرأ بحثًا عن إجابات لأسئلتك، مع ملاحظات مختصرة بكلماتك.", icon: BookOpenText, tint: "bg-sky-100 text-sky-700 dark:bg-sky-950/50 dark:text-sky-200" },
  { id: "recite", title: "تسميع", hint: "أغلق المصدر واشرح الفكرة بصوتك أو اكتب خلاصة قصيرة دون النظر.", icon: Mic2, tint: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-200" },
  { id: "review", title: "مراجعة", hint: "عد إلى أسئلتك وخلاصتك، ثم حدّد نقطة واحدة للمراجعة القادمة.", icon: RefreshCcw, tint: "bg-rose-100 text-rose-700 dark:bg-rose-950/50 dark:text-rose-200" },
] as const;

type StudyStepId = typeof steps[number]["id"];

function formatDuration(totalSeconds: number) {
  const seconds = Math.max(0, totalSeconds);
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const remainder = seconds % 60;
  return [hours, minutes, remainder].map(value => String(value).padStart(2, "0")).join(":");
}

export default function Study() {
  const utils = trpc.useUtils();
  const books = trpc.books.list.useQuery();
  const activeSession = trpc.study.activeSession.useQuery(undefined, { refetchInterval: 15_000 });
  const [bookId, setBookId] = useState("");
  const [chapterId, setChapterId] = useState("none");
  const [note, setNote] = useState("");
  const [clock, setClock] = useState(Date.now());
  const detail = trpc.books.detail.useQuery({ id: Number(bookId) || 1 }, { enabled: Boolean(bookId) });

  useEffect(() => {
    if (activeSession.data && !bookId) {
      setBookId(String(activeSession.data.bookId));
      setChapterId(activeSession.data.chapterId ? String(activeSession.data.chapterId) : "none");
    }
  }, [activeSession.data?.id, bookId]);

  useEffect(() => {
    if (!activeSession.data) return;
    setClock(Date.now());
    const timer = window.setInterval(() => setClock(Date.now()), 1_000);
    return () => window.clearInterval(timer);
  }, [activeSession.data?.id]);

  const currentSession = activeSession.data;
  const elapsedSeconds = currentSession ? Math.floor((clock - new Date(currentSession.createdAt).getTime()) / 1_000) : 0;
  const completed = useMemo(() => new Set(detail.data?.completedSteps || []), [detail.data?.completedSteps]);

  const start = trpc.study.startSession.useMutation({
    onSuccess: () => {
      void activeSession.refetch();
      void detail.refetch();
      toast.success("بدأت جلسة المذاكرة. سيظل المؤقت محفوظًا عند إعادة فتح الصفحة.");
    },
    onError: error => toast.error(error.message),
  });

  const finish = trpc.study.finishSession.useMutation({
    onSuccess: result => {
      void activeSession.refetch();
      void detail.refetch();
      void utils.books.list.invalidate();
      void utils.dashboard.summary.invalidate();
      setNote("");
      toast.success(`تم حفظ الجلسة (${formatDuration(result.durationSeconds)}).`);
    },
    onError: error => toast.error(error.message),
  });

  const finishCurrentSession = () => {
    if (!currentSession) return;
    finish.mutate({ sessionId: currentSession.id, notes: note.trim() || null });
  };

  return (
    <DashboardLayout title="المذاكرة SQ3R" description="حوّل القراءة السريعة إلى فهمٍ متين: امسح، تساءل، اقرأ، سمّع، ثم راجع في جلسة مركّزة واحدة." action={<div className="hidden items-center gap-2 rounded-2xl bg-secondary px-3 py-2 text-xs font-semibold text-primary sm:flex"><Sparkles className="size-4" />تعلّم بتركيز</div>}>
      {books.isError && <QueryErrorNotice onRetry={() => void books.refetch()} label="تعذّر تحميل كتبك للمذاكرة." />}
      {activeSession.isError && <QueryErrorNotice onRetry={() => void activeSession.refetch()} label="تعذّر استعادة جلسة المذاكرة المفتوحة." />}
      {detail.isError && <QueryErrorNotice onRetry={() => void detail.refetch()} label="تعذّر تحميل تفاصيل الكتاب المختار." />}

      {currentSession && currentSession.bookId !== Number(bookId) && (
        <section className="mb-5 flex flex-col gap-3 rounded-2xl border border-primary/20 bg-secondary/50 p-4 sm:flex-row sm:items-center sm:justify-between">
          <div><p className="font-semibold text-primary">لديك جلسة مفتوحة</p><p className="mt-1 text-sm text-muted-foreground">{books.data?.find(book => book.id === currentSession.bookId)?.title || "كتاب آخر"} · {steps.find(step => step.id === currentSession.step)?.title || "مذاكرة"} · {formatDuration(elapsedSeconds)}</p></div>
          <Button type="button" onClick={() => { setBookId(String(currentSession.bookId)); setChapterId(currentSession.chapterId ? String(currentSession.chapterId) : "none"); }} className="rounded-xl bg-primary">العودة إلى الجلسة</Button>
        </section>
      )}

      <section className="app-card mb-6 p-5 sm:p-6">
        <div className="grid gap-4 md:grid-cols-[1fr_1fr_auto]">
          <div><label className="mb-2 block text-sm font-semibold">اختر الكتاب أو المادة</label><Select value={bookId} onValueChange={value => { setBookId(value); setChapterId("none"); }}><SelectTrigger className="h-12 rounded-xl bg-background"><SelectValue placeholder="اختر كتابًا من المكتبة" /></SelectTrigger><SelectContent>{books.data?.map(book => <SelectItem key={book.id} value={String(book.id)}>{book.title}</SelectItem>)}</SelectContent></Select></div>
          <div><label className="mb-2 block text-sm font-semibold">الفصل <span className="font-normal text-muted-foreground">اختياري</span></label><Select value={chapterId} onValueChange={setChapterId} disabled={!bookId || Boolean(currentSession)}><SelectTrigger className="h-12 rounded-xl bg-background"><SelectValue placeholder="كل الكتاب" /></SelectTrigger><SelectContent><SelectItem value="none">كل الكتاب</SelectItem>{detail.data?.chapters.map(chapter => <SelectItem key={chapter.id} value={String(chapter.id)}>{chapter.title}</SelectItem>)}</SelectContent></Select></div>
          <div className="flex items-end"><Button variant="outline" className="w-full rounded-xl" disabled={Boolean(currentSession)} onClick={() => { setBookId(""); setChapterId("none"); }}>جلسة جديدة</Button></div>
        </div>
        {!books.isLoading && !books.data?.length && <p className="mt-4 rounded-xl bg-muted/60 p-3 text-sm text-muted-foreground">أضف كتابًا إلى المكتبة أولًا، ثم عُد لبدء جلسة SQ3R.</p>}
      </section>

      {bookId ? (
        <section className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_300px]">
          <div className="space-y-3">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isDone = completed.has(step.id);
              const isActive = currentSession?.bookId === Number(bookId) && currentSession?.step === step.id;
              const anotherSessionActive = Boolean(currentSession && !isActive);
              return (
                <article key={step.id} className={cn("app-card flex flex-col gap-4 p-5 transition-colors sm:flex-row sm:items-center", isDone && !isActive && "border-emerald-200 bg-emerald-50/35 dark:border-emerald-900/50 dark:bg-emerald-950/15", isActive && "border-primary/35 bg-secondary/35")}>
                  <span className="num flex size-9 shrink-0 items-center justify-center rounded-xl bg-muted text-sm font-semibold text-muted-foreground">{index + 1}</span>
                  <span className={cn("flex size-11 shrink-0 items-center justify-center rounded-2xl", step.tint)}><Icon className="size-5" /></span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2"><h2 className="font-bold">{step.title}</h2>{isDone && <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700 dark:text-emerald-300"><Check className="size-3.5" />لها سجل إكمال</span>}</div>
                    <p className="mt-1 text-sm leading-6 text-muted-foreground">{step.hint}</p>
                    {isActive && <div className="mt-3 inline-flex items-center gap-2 rounded-xl bg-primary/10 px-3 py-2 text-sm font-semibold tabular-nums text-primary"><Timer className="size-4" /><span dir="ltr">{formatDuration(elapsedSeconds)}</span><span className="text-xs font-normal">جلسة جارية</span></div>}
                  </div>
                  {isActive ? (
                    <Button type="button" disabled={finish.isPending} onClick={finishCurrentSession} className="shrink-0 rounded-xl bg-primary"><Square className="size-4" />إنهاء وحفظ</Button>
                  ) : (
                    <Button type="button" disabled={start.isPending || anotherSessionActive || activeSession.isLoading} onClick={() => start.mutate({ bookId: Number(bookId), chapterId: chapterId === "none" ? null : Number(chapterId), step: step.id })} variant={isDone ? "outline" : "default"} className={cn("pressable shrink-0 rounded-xl", !isDone && "bg-primary")}>
                      <Play className="size-4" />{isDone ? "إعادة الجلسة" : "ابدأ جلسة"}
                    </Button>
                  )}
                </article>
              );
            })}
          </div>
          <aside className="app-card h-fit p-5">
            <span className="flex size-10 items-center justify-center rounded-2xl bg-secondary text-primary"><Search className="size-5" /></span>
            <h2 className="mt-4 font-bold">ملاحظة الجلسة</h2>
            <p className="mt-1 text-sm leading-6 text-muted-foreground">دوّن سؤالًا أو خلاصة سريعة. تُحفظ الملاحظة عند إنهاء الجلسة.</p>
            <Textarea value={note} onChange={event => setNote(event.target.value)} placeholder="ما الفكرة التي تريد تذكّرها؟" className="mt-4 min-h-32 rounded-xl bg-background leading-7" maxLength={4_000} />
            <p className="mt-3 text-xs leading-5 text-muted-foreground">{currentSession && currentSession.bookId === Number(bookId) ? "أنه الجلسة لحفظ مدتها والملاحظة المرتبطة بها." : "ابدأ جلسة من إحدى الخطوات أولًا. يمكنك استكمالها لاحقًا حتى بعد إغلاق الصفحة."}</p>
          </aside>
        </section>
      ) : (
        <section className="app-card soft-grid flex min-h-80 flex-col items-center justify-center p-6 text-center">
          <span className="flex size-16 items-center justify-center rounded-3xl bg-secondary text-primary"><BookOpenText className="size-7" /></span>
          <h2 className="mt-5 text-xl font-bold">جلسة قراءة أكثر وعيًا</h2>
          <p className="mt-2 max-w-md text-sm leading-7 text-muted-foreground">اختر كتابًا من مكتبتك، ثم اتبع الخطوات الخمس واحدة تلو الأخرى لتحوّل ما تقرؤه إلى فهمٍ قابل للاستدعاء.</p>
        </section>
      )}
    </DashboardLayout>
  );
}

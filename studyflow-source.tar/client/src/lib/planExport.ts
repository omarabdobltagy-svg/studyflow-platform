export type ExportPlan = {
  title: string;
  summary: string;
  durationLabel: string;
  steps: { day: string; title: string; detail: string; minutes: number; category: string }[];
  habits: { title: string; cue: string }[];
  reviewQuestion: string;
};

export function buildPlanFollowUpDocument(plan: ExportPlan, studentName?: string) {
  const lines = [
    `# ${plan.title}`,
    studentName ? `الطالب: ${studentName}` : "",
    `المدة: ${plan.durationLabel}`,
    "",
    plan.summary,
    "",
    "## مراحل التنفيذ",
    ...plan.steps.map((step, index) => `${index + 1}. ${step.day} — ${step.title} (${step.minutes} دقيقة)\n   ${step.detail}\n   التصنيف: ${step.category}`),
    "",
    "## العادات الداعمة",
    ...plan.habits.map(habit => `- ${habit.title}: ${habit.cue}`),
    "",
    `## سؤال المراجعة\n${plan.reviewQuestion}`,
  ];
  return lines.filter(Boolean).join("\n");
}

export function printPlanAsPdf() {
  window.print();
}

export type CalendarDisplayItem = { id: string; title: string; startAt: Date | string };

export function localDateKey(date: Date) {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

export function buildCalendarDays(base: Date, count: number) {
  const start = count === 7
    ? new Date(base.getFullYear(), base.getMonth(), base.getDate())
    : new Date(base.getFullYear(), base.getMonth(), 1);
  const offset = (start.getDay() + 1) % 7;
  start.setDate(start.getDate() - offset);
  return Array.from({ length: count }, (_, index) => {
    const current = new Date(start);
    current.setDate(start.getDate() + index);
    return current;
  });
}

export function groupCalendarItems<T extends CalendarDisplayItem>(items: T[]) {
  return items.reduce<Record<string, T[]>>((groups, item) => {
    const key = localDateKey(new Date(item.startAt));
    (groups[key] ||= []).push(item);
    return groups;
  }, {});
}

export function calendarHasItem(days: Date[], groupedItems: Record<string, CalendarDisplayItem[]>, itemId: string) {
  return days.some(day => groupedItems[localDateKey(day)]?.some(item => item.id === itemId));
}

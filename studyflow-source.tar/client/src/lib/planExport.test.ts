import { describe, expect, it } from "vitest";
import { buildPlanFollowUpDocument, type ExportPlan } from "./planExport";

const plan: ExportPlan = {
  title: "عودة هادئة للمذاكرة",
  summary: "خطة قصيرة قابلة للاستمرار.",
  durationLabel: "7 أيام",
  steps: [{ day: "اليوم 1", title: "مراجعة درس", detail: "جلسة بداية قصيرة", minutes: 25, category: "العربي" }],
  habits: [{ title: "افتح الكتاب", cue: "بعد كوب الماء" }],
  reviewQuestion: "ما أسهل خطوة أكررها غدًا؟",
};

describe("plan export", () => {
  it("builds an Arabic follow-up document with stages and habits", () => {
    const output = buildPlanFollowUpDocument(plan, "أحمد");
    expect(output).toContain("# عودة هادئة للمذاكرة");
    expect(output).toContain("الطالب: أحمد");
    expect(output).toContain("مراجعة درس");
    expect(output).toContain("العادات الداعمة");
    expect(output).toContain("سؤال المراجعة");
  });
});

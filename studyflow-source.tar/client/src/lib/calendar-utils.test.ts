import { describe, expect, it } from "vitest";
import { buildCalendarDays, calendarHasItem, groupCalendarItems } from "./calendar-utils";

describe("عرض المهام المؤرخة في التقويم", () => {
  const task = { id: "task-17", title: "مراجعة ملخص الدرس", startAt: new Date("2026-08-20T12:00:00") };
  const grouped = groupCalendarItems([task]);

  it("يضع المهمة المؤرخة في مجموعة يومها", () => {
    expect(grouped["2026-08-20"]).toEqual([task]);
  });

  it("يعرض المهمة داخل شبكة الشهر التي تضم تاريخها", () => {
    const monthDays = buildCalendarDays(new Date("2026-08-15T12:00:00"), 42);
    expect(calendarHasItem(monthDays, grouped, task.id)).toBe(true);
  });

  it("يعرض المهمة داخل شبكة الأسبوع عندما يقع تاريخها في الأسبوع المعروض", () => {
    const weekDays = buildCalendarDays(new Date("2026-08-15T12:00:00"), 7);
    expect(calendarHasItem(weekDays, grouped, task.id)).toBe(true);
  });
});

import { describe, expect, it } from "vitest";
import { buildDailyReminderDraft, createReminderCron, isReminderAlreadyDelivered } from "./reminders";

describe("createReminderCron", () => {
  it("يحوّل وقت الرياض المحلي إلى جدولة UTC", () => {
    expect(createReminderCron("08:00", "Asia/Riyadh", new Date("2026-01-15T00:00:00.000Z"))).toBe("0 0 5 * * *");
  });

  it("يحترم التوقيت الصيفي عند تحويل وقت نيويورك", () => {
    expect(createReminderCron("08:00", "America/New_York", new Date("2026-07-15T00:00:00.000Z"))).toBe("0 0 12 * * *");
  });

  it("يرفض المنطقة الزمنية غير الصحيحة", () => {
    expect(() => createReminderCron("08:00", "Invalid/Zone")).toThrow("المنطقة الزمنية غير صالحة");
  });
});

describe("اختيار محتوى التذكير اليومي", () => {
  const now = new Date("2026-08-18T09:00:00.000Z");

  it("يختار عناصر اليوم في المنطقة الزمنية المحلية ويرتب الأولوية: مهمة ثم موعد ثم روتين", () => {
    const draft = buildDailyReminderDraft({
      timezone: "Asia/Riyadh",
      now,
      tasks: [
        { id: 1, title: "حل التمارين", dueAt: new Date("2026-08-18T18:00:00.000Z") },
        { id: 2, title: "موعد قديم", dueAt: new Date("2026-08-17T20:00:00.000Z") },
      ],
      events: [{ id: 3, title: "جلسة مراجعة", startAt: new Date("2026-08-18T13:00:00.000Z") }],
      routineItems: [{ id: 4 }],
    });

    expect(draft.dateKey).toBe("2026-08-18");
    expect(draft.dueToday).toHaveLength(1);
    expect(draft.todayEvents).toHaveLength(1);
    expect(draft.notification).toMatchObject({ kind: "task", sourceId: 1 });
    expect(draft.notification?.content).toContain("حل التمارين");
    expect(draft.notification?.content).toContain("جلسة مراجعة");
    expect(draft.notification?.content).toContain("روتينك اليومي");
  });

  it("ينتج مسودة فارغة عند غياب كل العناصر ويحمي من إرسال نسخة ثانية في اليوم نفسه", () => {
    const draft = buildDailyReminderDraft({ timezone: "Asia/Riyadh", now, tasks: [], events: [], routineItems: [] });
    expect(draft.notification).toBeNull();
    expect(isReminderAlreadyDelivered("2026-08-18", draft.dateKey)).toBe(true);
    expect(isReminderAlreadyDelivered("2026-08-17", draft.dateKey)).toBe(false);
  });
});

import { afterEach, describe, expect, it, vi } from "vitest";
import { addLibraryAttachment, approvePlanAsGoalTree, deleteLibraryAttachment, setDbForTests, toggleTask, undoTaskChange, startStudySession, finishStudySession, updateBook, updateChapter, updateTask } from "./db";

function createDbMock(selectResults: unknown[][]) {
  const where = vi.fn(() => ({ limit: vi.fn(async () => selectResults.shift() ?? []) }));
  const from = vi.fn(() => ({ where }));
  const select = vi.fn(() => ({ from }));
  const updateWhere = vi.fn(async () => [{ affectedRows: 1 }]);
  const updateSet = vi.fn(() => ({ where: updateWhere }));
  const update = vi.fn(() => ({ set: updateSet }));
  const insertValues = vi.fn(async () => [{ insertId: 30 }]);
  const insert = vi.fn(() => ({ values: insertValues }));
  const deleteWhere = vi.fn(async () => [{ affectedRows: 1 }]);
  const remove = vi.fn(() => ({ where: deleteWhere }));
  const db = { select, update, insert, delete: remove };
  const transaction = vi.fn(async (callback: (tx: typeof db) => Promise<unknown>) => callback(db));
  return { db: { ...db, transaction }, update, updateSet, updateWhere, insert, insertValues, remove, deleteWhere, transaction };
}

function createPlanApprovalDbMock() {
  const insertValues = vi.fn()
    .mockResolvedValueOnce([{ insertId: 100 }])
    .mockResolvedValueOnce([{ insertId: 101 }])
    .mockResolvedValueOnce([{ insertId: 201 }])
    .mockResolvedValueOnce([{ insertId: 102 }])
    .mockResolvedValueOnce([{ insertId: 202 }]);
  const insert = vi.fn(() => ({ values: insertValues }));
  const transaction = vi.fn(async (callback: (tx: { insert: typeof insert }) => Promise<unknown>) => callback({ insert }));
  return { db: { transaction }, transaction, insert, insertValues };
}

afterEach(() => setDbForTests(undefined));

describe("المسارات الفعلية لتعديل المهمة والتراجع", () => {
  it("يسجل وقت الإكمال داخل نفس المعاملة ويحفظ الحالة السابقة للتراجع", async () => {
    const mock = createDbMock([[{ id: 5, status: "todo", completedAt: null }]]);
    setDbForTests(mock.db as never);

    const result = await toggleTask(7, 5, true);

    expect(result).toMatchObject({ changeId: 30 });
    expect(mock.transaction).toHaveBeenCalledOnce();
    expect(mock.updateSet).toHaveBeenCalledWith(expect.objectContaining({ status: "done", completedAt: expect.any(Date) }));
    expect(mock.insertValues).toHaveBeenCalledWith(expect.objectContaining({
      userId: 7,
      taskId: 5,
      previousStatus: "todo",
      previousCompletedAt: null,
      nextStatus: "done",
      expiresAt: expect.any(Date),
    }));
  });

  it("لا ينشئ سجل تراجع جديدًا إذا كانت المهمة بالفعل في الحالة المطلوبة", async () => {
    const mock = createDbMock([[{ id: 5, status: "done", completedAt: new Date("2026-11-20T10:00:00.000Z") }]]);
    setDbForTests(mock.db as never);

    await expect(toggleTask(7, 5, true)).resolves.toBeNull();
    expect(mock.update).not.toHaveBeenCalled();
    expect(mock.insert).not.toHaveBeenCalled();
  });

  it("يحدّث المهمة المملوكة بعد التحقق من ملكية الهدف والكتاب", async () => {
    const mock = createDbMock([[{ id: 5 }], [{ id: 3 }], [{ id: 9 }]]);
    setDbForTests(mock.db as never);
    const dueAt = new Date("2026-08-22T09:00:00.000Z");

    await updateTask(7, 5, { title: "إصدار محدّث", notes: "ملاحظات", category: "دراسة", priority: "high", dueAt, goalId: 3, bookId: 9 });

    expect(mock.updateSet).toHaveBeenCalledWith({ title: "إصدار محدّث", notes: "ملاحظات", category: "دراسة", priority: "high", dueAt, goalId: 3, bookId: 9 });
    expect(mock.updateWhere).toHaveBeenCalledOnce();
  });

  it("يرفض تعديل المهمة حين لا ينتمي الهدف المرتبط إلى مساحة المستخدم", async () => {
    const mock = createDbMock([[{ id: 5 }], []]);
    setDbForTests(mock.db as never);

    await expect(updateTask(7, 5, { title: "إصدار محدّث", goalId: 99 })).rejects.toThrow("هدف غير موجود في مساحتك");
    expect(mock.update).not.toHaveBeenCalled();
  });

  it("يرفض تعديل المهمة حين لا ينتمي الكتاب المرتبط إلى مكتبة المستخدم", async () => {
    const mock = createDbMock([[{ id: 5 }], []]);
    setDbForTests(mock.db as never);

    await expect(updateTask(7, 5, { title: "إصدار محدّث", bookId: 99 })).rejects.toThrow("كتاب غير موجود في مكتبتك");
    expect(mock.update).not.toHaveBeenCalled();
  });

  it("يعيد الحالة السابقة ويحذف سجل التراجع عندما تكون المهلة صالحة", async () => {
    const previousCompletedAt = new Date("2026-11-18T12:30:00.000Z");
    const mock = createDbMock([[{ id: 12, taskId: 5, previousStatus: "done", previousCompletedAt, expiresAt: new Date(Date.now() + 60_000) }]]);
    setDbForTests(mock.db as never);

    await undoTaskChange(7, 12);

    expect(mock.updateSet).toHaveBeenCalledWith({ status: "done", completedAt: previousCompletedAt });
    expect(mock.deleteWhere).toHaveBeenCalledOnce();
    expect(mock.transaction).toHaveBeenCalledOnce();
  });

  it("يرفض التراجع إذا غاب السجل أو انتهت مهلة العشر دقائق", async () => {
    const missing = createDbMock([[]]);
    setDbForTests(missing.db as never);
    await expect(undoTaskChange(7, 12)).rejects.toThrow("انتهت مهلة التراجع");

    const expired = createDbMock([[{ id: 12, taskId: 5, previousStatus: "todo", expiresAt: new Date(Date.now() - 60_000) }]]);
    setDbForTests(expired.db as never);
    await expect(undoTaskChange(7, 12)).rejects.toThrow("انتهت مهلة التراجع");
    expect(expired.update).not.toHaveBeenCalled();
  });
});

describe("المسارات الفعلية لإرفاق ملفات المكتبة", () => {
  const attachment = { bookId: 9, chapterId: 4, fileName: "ملخص.pdf", fileKey: "library/9/ملخص.pdf", fileUrl: "https://files.example/summary", mimeType: "application/pdf", sizeBytes: 1200 };

  it("يسجل المرفق عندما يملك المستخدم الكتاب والفصل يتبعه", async () => {
    const mock = createDbMock([[{ id: 9 }], [{ id: 4 }]]);
    setDbForTests(mock.db as never);

    await addLibraryAttachment(7, attachment);

    expect(mock.insertValues).toHaveBeenCalledWith({ ...attachment, userId: 7, chapterId: 4 });
  });

  it("يرفض التسجيل عند عدم ملكية الكتاب أو عدم تبعية الفصل له", async () => {
    const foreignBook = createDbMock([[]]);
    setDbForTests(foreignBook.db as never);
    await expect(addLibraryAttachment(7, attachment)).rejects.toThrow("كتاب لا تملكه");
    expect(foreignBook.insert).not.toHaveBeenCalled();

    const foreignChapter = createDbMock([[{ id: 9 }], []]);
    setDbForTests(foreignChapter.db as never);
    await expect(addLibraryAttachment(7, attachment)).rejects.toThrow("الفصل المحدد لا يتبع لهذا الكتاب");
    expect(foreignChapter.insert).not.toHaveBeenCalled();
  });
});

describe("المسارات الفعلية لملاحظات المكتبة وإدارة مرفقاتها", () => {
  it("يحفظ ملاحظات الكتاب والفصل بعد التحقق من ملكية الكتاب", async () => {
    const book = createDbMock([[{ id: 9 }]]);
    setDbForTests(book.db as never);
    await updateBook(7, 9, { title: "منهج جديد", author: "المؤلف", subject: "دراسة", totalPages: 120, coverColor: "violet", notes: "ملاحظة الكتاب" });
    expect(book.updateSet).toHaveBeenCalledWith(expect.objectContaining({ notes: "ملاحظة الكتاب" }));

    const chapter = createDbMock([[{ id: 4, bookId: 9, totalPages: 20 }], [{ id: 9 }]]);
    setDbForTests(chapter.db as never);
    await updateChapter(7, 4, { title: "الفصل الأول", totalPages: 20, completedPages: 20, notes: "ملاحظة الفصل" });
    expect(chapter.updateSet).toHaveBeenCalledWith(expect.objectContaining({ notes: "ملاحظة الفصل", status: "completed" }));
  });

  it("يرفض تعديل كتاب غير مملوك ويرفض حذف مرفق لا يملكه المستخدم", async () => {
    const foreignBook = createDbMock([[]]);
    setDbForTests(foreignBook.db as never);
    await expect(updateBook(7, 9, { title: "منهج جديد", notes: "محاولة" })).rejects.toThrow("لا يمكن تعديل كتاب لا تملكه");
    expect(foreignBook.update).not.toHaveBeenCalled();

    const foreignAttachment = createDbMock([]);
    foreignAttachment.deleteWhere.mockResolvedValueOnce([{ affectedRows: 0 }]);
    setDbForTests(foreignAttachment.db as never);
    await expect(deleteLibraryAttachment(7, 44)).rejects.toThrow("لم نعثر على هذا المرفق أو لا تملك حذفه");
  });
});

describe("اعتماد خطة الدورة في شجرة الأهداف", () => {
  it("ينشئ هدفًا رئيسيًا ومراحل ومهمة لكل مرحلة داخل معاملة واحدة وبملكية المستخدم", async () => {
    const mock = createPlanApprovalDbMock();
    setDbForTests(mock.db as never);

    const result = await approvePlanAsGoalTree(7, {
      title: "أساسيات النحو",
      summary: "خطة مبسطة لتثبيت أساسيات النحو في جلستين.",
      steps: [
        { day: 1, title: "مراجعة المبتدأ والخبر", detail: "شاهد الدرس وحل خمسة أمثلة.", minutes: 45, category: "نحو" },
        { day: 2, title: "تدريب الإعراب", detail: "أعرب عشر جمل قصيرة.", minutes: 35, category: "نحو" },
      ],
    });

    expect(result).toEqual({ parentGoalId: 100, stageCount: 2, taskCount: 2 });
    expect(mock.transaction).toHaveBeenCalledOnce();
    expect(mock.insertValues).toHaveBeenCalledTimes(5);
    expect(mock.insertValues).toHaveBeenNthCalledWith(1, expect.objectContaining({ userId: 7, title: "أساسيات النحو", kind: "long", category: "خطة تدريبية" }));
    expect(mock.insertValues).toHaveBeenNthCalledWith(2, expect.objectContaining({ userId: 7, parentGoalId: 100, title: "المرحلة 1: مراجعة المبتدأ والخبر", sortOrder: 1 }));
    expect(mock.insertValues).toHaveBeenNthCalledWith(3, expect.objectContaining({ userId: 7, goalId: 101, title: "مراجعة المبتدأ والخبر", estimatedMinutes: 45 }));
    expect(mock.insertValues.mock.calls.map(([values]) => values.userId)).toEqual([7, 7, 7, 7, 7]);
  });

  it("يضع مواعيد حقيقية للمهام والمراحل عند اعتماد خطة مجدولة", async () => {
    const mock = createPlanApprovalDbMock();
    setDbForTests(mock.db as never);
    await approvePlanAsGoalTree(7, {
      title: "مراجعة أسبوعية",
      summary: "خطة قصيرة",
      steps: [
        { day: 1, title: "الخطوة الأولى", detail: "شرح", minutes: 45, category: "دراسة" },
        { day: 2, title: "الخطوة الثانية", detail: "حل", minutes: 45, category: "تطبيق" },
      ],
    }, { startDate: "2026-11-21", dailyMinutes: 60 });

    const firstStage = mock.insertValues.mock.calls[1][0] as Record<string, unknown>;
    const firstTask = mock.insertValues.mock.calls[2][0] as Record<string, unknown>;
    const secondStage = mock.insertValues.mock.calls[3][0] as Record<string, unknown>;
    const secondTask = mock.insertValues.mock.calls[4][0] as Record<string, unknown>;
    expect(firstStage.targetDate).toEqual(new Date("2026-11-21T12:00:00.000Z"));
    expect(firstTask.dueAt).toEqual(new Date("2026-11-21T12:00:00.000Z"));
    expect(secondStage.targetDate).toEqual(new Date("2026-11-22T12:00:00.000Z"));
    expect(secondTask.dueAt).toEqual(new Date("2026-11-22T12:00:00.000Z"));
  });

  it("يرفض الخطة بلا عنوان أو مراحل قبل بدء أي معاملة أو إنشاء", async () => {
    const missingTitle = createPlanApprovalDbMock();
    setDbForTests(missingTitle.db as never);
    await expect(approvePlanAsGoalTree(7, { title: "  ", summary: "ملخص", steps: [{ day: 1, title: "جلسة", detail: "تفصيل", minutes: 25, category: "دراسة" }] })).rejects.toThrow("بلا عنوان ومراحل عملية");
    expect(missingTitle.transaction).not.toHaveBeenCalled();

    const missingSteps = createPlanApprovalDbMock();
    setDbForTests(missingSteps.db as never);
    await expect(approvePlanAsGoalTree(7, { title: "خطة فارغة", summary: "ملخص", steps: [] })).rejects.toThrow("بلا عنوان ومراحل عملية");
    expect(missingSteps.transaction).not.toHaveBeenCalled();
  });
});


describe("جلسات المذاكرة المؤقتة", () => {
  it("يتحقق من ملكية الكتاب ثم ينشئ جلسة نشطة بخطوة صحيحة", async () => {
    const mock = createDbMock([[{ id: 9 }], []]);
    setDbForTests(mock.db as never);
    const result = await startStudySession(7, { bookId: 9, step: "read" });
    expect(result).toMatchObject({ sessionId: 30, startedAt: expect.any(Date) });
    expect(mock.insertValues).toHaveBeenCalledWith(expect.objectContaining({ userId: 7, bookId: 9, step: "read", status: "active" }));
  });

  it("يرفض إنهاء جلسة لا يملكها المستخدم أو أُغلقت بالفعل", async () => {
    const mock = createDbMock([[]]);
    setDbForTests(mock.db as never);
    await expect(finishStudySession(7, 55)).rejects.toThrow("جلسة المذاكرة غير موجودة");
    expect(mock.update).not.toHaveBeenCalled();
  });

  it("يغلق الجلسة مرة واحدة ويحفظ وقت الانتهاء والملاحظة", async () => {
    const createdAt = new Date(Date.now() - 65_000);
    const mock = createDbMock([[{ id: 55, status: "active", createdAt, notes: null }]]);
    setDbForTests(mock.db as never);
    const result = await finishStudySession(7, 55, "فهمت الفكرة الرئيسية");
    expect(result.durationSeconds).toBeGreaterThanOrEqual(60);
    expect(mock.updateSet).toHaveBeenCalledWith(expect.objectContaining({ status: "completed", notes: "فهمت الفكرة الرئيسية", completedAt: expect.any(Date) }));
  });
});

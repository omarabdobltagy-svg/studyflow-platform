import { describe, expect, it } from "vitest";
import { analyticsPeriodForDate, analyticsPeriodsForDate, assertAttachmentTargetOwnership, assertTaskRelationOwnership, buildTaskUpdateValues, calculateProgress, clampCompletedPages, getDateKeyInTimezone, getPreviousTaskStatusForUndo, mergeCalendarItems, schedulePlanStepDates } from "./db";
import { decodeAndValidateAttachment, isSupportedAttachmentMime } from "./attachments";

describe("روابط المهمة", () => {
  it("تسمح بالربط حين يكون السجل موجودًا داخل مساحة المستخدم", () => {
    expect(() => assertTaskRelationOwnership({ id: 12 }, "goal")).not.toThrow();
    expect(() => assertTaskRelationOwnership({ id: 9 }, "book")).not.toThrow();
  });

  it("ترفض ربط الهدف أو الكتاب غير المملوك", () => {
    expect(() => assertTaskRelationOwnership(undefined, "goal")).toThrow("هدف غير موجود في مساحتك");
    expect(() => assertTaskRelationOwnership(null, "book")).toThrow("كتاب غير موجود في مكتبتك");
  });
});

describe("تعديل المهام والتراجع", () => {
  it("يبني قيم التعديل كاملة ويحافظ على الحقول الاختيارية الفارغة كقيمة null", () => {
    const dueAt = new Date("2026-08-21T09:00:00.000Z");
    expect(buildTaskUpdateValues({ title: "مراجعة الوحدة", notes: "بطاقات سريعة", category: "دراسة", priority: "high", dueAt, goalId: 3, bookId: 7 })).toEqual({
      title: "مراجعة الوحدة", notes: "بطاقات سريعة", category: "دراسة", priority: "high", dueAt, goalId: 3, bookId: 7,
    });
    expect(buildTaskUpdateValues({ title: "مهمة بلا روابط" })).toMatchObject({ notes: null, category: "عام", priority: "medium", dueAt: null, goalId: null, bookId: null });
  });

  it("يسمح بالتراجع قبل انتهاء المهلة ويرفض السجل المنتهي أو المفقود", () => {
    const now = new Date("2026-08-18T10:00:00.000Z");
    expect(getPreviousTaskStatusForUndo({ previousStatus: "todo", expiresAt: new Date("2026-08-18T10:10:00.000Z") }, now)).toBe("todo");
    expect(() => getPreviousTaskStatusForUndo({ previousStatus: "done", expiresAt: new Date("2026-08-18T09:59:00.000Z") }, now)).toThrow("انتهت مهلة التراجع");
    expect(() => getPreviousTaskStatusForUndo(undefined, now)).toThrow("انتهت مهلة التراجع");
  });
});

describe("ملكية مرفقات المكتبة", () => {
  it("لا يسمح بالإرفاق بكتاب أو فصل خارج علاقة المستخدم والكتاب", () => {
    expect(() => assertAttachmentTargetOwnership({ id: 2 }, { id: 9 })).not.toThrow();
    expect(() => assertAttachmentTargetOwnership(undefined, { id: 9 })).toThrow("كتاب لا تملكه");
    expect(() => assertAttachmentTargetOwnership({ id: 2 }, undefined)).toThrow("الفصل المحدد لا يتبع");
  });
});

describe("دمج عناصر التقويم", () => {
  it("يضم المهام المؤرخة والأحداث ويرتّبها زمنيًا مع لون الأولوية", () => {
    const items = mergeCalendarItems(
      [{ id: 5, title: "جلسة مراجعة", type: "study", startAt: new Date("2026-08-21T16:00:00Z"), endAt: null, allDay: false, color: "violet" }],
      [
        { id: 2, title: "تسليم ملخص", dueAt: new Date("2026-08-20T00:00:00Z"), priority: "high" },
        { id: 3, title: "بلا موعد", dueAt: null, priority: "low" },
      ]
    );

    expect(items).toHaveLength(2);
    expect(items[0]).toMatchObject({ id: "task-2", type: "task", source: "task", allDay: true, color: "rose" });
    expect(items[1]).toMatchObject({ id: "event-5", type: "study", source: "event" });
  });
});

describe("احتساب تقدّم الأهداف والكتب", () => {
  it("يحسب نسبة مكتملة مقربة ويعيد صفرًا في غياب عناصر قابلة للحساب", () => {
    expect(calculateProgress(1, 3)).toBe(33);
    expect(calculateProgress(0, 0)).toBe(0);
  });

  it("يحصر نسبة التقدم بين صفر ومئة عند البيانات غير المتوقعة", () => {
    expect(calculateProgress(9, 3)).toBe(100);
    expect(calculateProgress(-2, 10)).toBe(0);
  });

  it("يمنع حفظ صفحات مكتملة سالبة أو تتجاوز حجم الفصل", () => {
    expect(clampCompletedPages(-4, 25)).toBe(0);
    expect(clampCompletedPages(31, 25)).toBe(25);
    expect(clampCompletedPages(12, 25)).toBe(12);
  });
});


describe("التواريخ والفترات الزمنية", () => {
  it("يحسب اليوم المحلي وفق المنطقة الزمنية وليس UTC فقط", () => {
    const instant = new Date("2026-11-20T22:30:00.000Z");
    expect(getDateKeyInTimezone(instant, "Africa/Cairo")).toBe("2026-11-21");
    expect(getDateKeyInTimezone(instant, "UTC")).toBe("2026-11-20");
  });

  it("يصنف إكمال المهام إلى اليوم والأسبوع والشهر دون خلط آخر تعديل بتاريخ الإكمال", () => {
    const now = new Date("2026-11-21T10:00:00.000Z");
    expect(analyticsPeriodsForDate(new Date("2026-11-21T08:00:00.000Z"), now, "Africa/Cairo")).toEqual(["daily", "weekly", "monthly"]);
    expect(analyticsPeriodsForDate(new Date("2026-11-19T08:00:00.000Z"), now, "Africa/Cairo")).toEqual(["weekly", "monthly"]);
    // The product calendar starts its week on Saturday, so Friday remains in the same weekly bucket.
    expect(analyticsPeriodsForDate(new Date("2026-11-20T08:00:00.000Z"), now, "Africa/Cairo")).toEqual(["weekly", "monthly"]);
    expect(analyticsPeriodsForDate(new Date("2026-11-10T08:00:00.000Z"), now, "Africa/Cairo")).toEqual(["monthly"]);
    expect(analyticsPeriodsForDate(new Date("2026-10-31T08:00:00.000Z"), now, "Africa/Cairo")).toEqual([]);
    expect(analyticsPeriodForDate(new Date("2026-11-21T08:00:00.000Z"), now, "Africa/Cairo")).toBe("daily");
  });
});

describe("التحقق من مرفقات المكتبة", () => {
  it("يقبل ترويسة PDF الصحيحة ويرفض MIME غير المدعوم", () => {
    const pdf = Buffer.from("%PDF-1.7\nfixture").toString("base64");
    expect(decodeAndValidateAttachment(pdf, "application/pdf").subarray(0, 5).toString("ascii")).toBe("%PDF-");
    expect(() => decodeAndValidateAttachment(pdf, "text/html")).toThrow("نوع الملف غير مدعوم");
    expect(isSupportedAttachmentMime("application/pdf")).toBe(true);
    expect(isSupportedAttachmentMime("text/html")).toBe(false);
  });

  it("يرفض الملف الذي لا يطابق نوعه المعلن أو محتوى فارغًا", () => {
    const text = Buffer.from("not a pdf").toString("base64");
    expect(() => decodeAndValidateAttachment(text, "application/pdf")).toThrow("لا يطابق نوعه المعلن");
    expect(() => decodeAndValidateAttachment("", "application/pdf")).toThrow("تعذّر قراءة الملف");
  });
});


describe("جدولة خطوات الخطة", () => {
  it("يوزّع الخطوات على أيام حسب الدقائق المتاحة ويحتفظ بترتيبها", () => {
    const dates = schedulePlanStepDates("2026-11-21", [{ minutes: 45 }, { minutes: 60 }, { minutes: 30 }, { minutes: 25 }], 100);
    expect(dates.map(date => date.toISOString().slice(0, 10))).toEqual(["2026-11-21", "2026-11-22", "2026-11-22", "2026-11-23"]);
  });

  it("يرفض تاريخًا غير صالح ويحافظ على خطوة أطول من السعة في يوم منفصل", () => {
    expect(() => schedulePlanStepDates("2026-02-30", [{ minutes: 30 }], 120)).toThrow("تاريخ بداية الخطة غير صالح");
    const dates = schedulePlanStepDates("2026-11-21", [{ minutes: 150 }, { minutes: 25 }], 120);
    expect(dates[1].getUTCDate()).toBe(dates[0].getUTCDate() + 1);
  });
});

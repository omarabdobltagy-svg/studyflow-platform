import { beforeEach, describe, expect, it, vi } from "vitest";

vi.mock("./reminders", () => ({
  createReminderCron: vi.fn(),
  getReminderPreferences: vi.fn(),
  listReminderNotifications: vi.fn(),
  markReminderRead: vi.fn(),
  saveReminderPreferences: vi.fn(),
  saveReminderSchedule: vi.fn(),
}));

vi.mock("./_core/heartbeat", () => ({
  createHeartbeatJob: vi.fn(),
  updateHeartbeatJob: vi.fn(),
}));

import { appRouter } from "./routers";
import { createHeartbeatJob, updateHeartbeatJob } from "./_core/heartbeat";
import { createReminderCron, getReminderPreferences, markReminderRead, saveReminderPreferences, saveReminderSchedule } from "./reminders";

function callerFor(userId: number | null) {
  return appRouter.createCaller({
    user: userId === null ? null : ({ id: userId, openId: `user-${userId}`, name: "مستخدم الاختبار", role: "user" } as never),
    req: { headers: { cookie: "app_session_id=test-token" } } as never,
    res: {} as never,
  });
}

describe("إجراءات التذكيرات المحمية", () => {
  beforeEach(() => vi.resetAllMocks());

  it("ينشئ جدولة التذكير باسم المستخدم المسجّل ويحفظ معرّفها", async () => {
    vi.mocked(getReminderPreferences)
      .mockResolvedValueOnce({ id: null, userId: 7, enabled: false, dailyTime: "08:00", timezone: "UTC", scheduleCronTaskUid: null, nextExecutionAt: null, lastDeliveredDate: null })
      .mockResolvedValueOnce({ id: 1, userId: 7, enabled: true, dailyTime: "09:15", timezone: "Asia/Riyadh", scheduleCronTaskUid: "job-1", nextExecutionAt: new Date("2026-08-19T06:15:00.000Z"), lastDeliveredDate: null } as never);
    vi.mocked(createReminderCron).mockReturnValue("0 15 6 * * *");
    vi.mocked(createHeartbeatJob).mockResolvedValue({ taskUid: "job-1", nextExecutionAt: "2026-08-19T06:15:00.000Z" } as never);

    const result = await callerFor(7).reminders.configure({ enabled: true, dailyTime: "09:15", timezone: "Asia/Riyadh" });

    expect(saveReminderPreferences).toHaveBeenCalledWith(7, { enabled: true, dailyTime: "09:15", timezone: "Asia/Riyadh" });
    expect(createHeartbeatJob).toHaveBeenCalledWith(expect.objectContaining({ name: "studyflow-reminder-7", cron: "0 15 6 * * *" }), "test-token");
    expect(saveReminderSchedule).toHaveBeenCalledWith(7, "job-1", new Date("2026-08-19T06:15:00.000Z"));
    expect(result).toMatchObject({ userId: 7, scheduleCronTaskUid: "job-1" });
  });

  it("يرفض المنطقة الزمنية غير الصالحة قبل حفظ تفضيلات التذكير", async () => {
    await expect(callerFor(7).reminders.configure({ enabled: true, dailyTime: "09:15", timezone: "Invalid/Zone" })).rejects.toMatchObject({ code: "BAD_REQUEST" });
    expect(saveReminderPreferences).not.toHaveBeenCalled();
    expect(createHeartbeatJob).not.toHaveBeenCalled();
  });

  it("لا يفعّل التفضيلات عند فشل إنشاء الجدولة الخارجية", async () => {
    vi.mocked(getReminderPreferences).mockResolvedValueOnce({ id: null, userId: 7, enabled: false, dailyTime: "08:00", timezone: "UTC", scheduleCronTaskUid: null, nextExecutionAt: null, lastDeliveredDate: null });
    vi.mocked(createReminderCron).mockReturnValue("0 15 6 * * *");
    vi.mocked(createHeartbeatJob).mockRejectedValueOnce(new Error("scheduler unavailable"));

    await expect(callerFor(7).reminders.configure({ enabled: true, dailyTime: "09:15", timezone: "Asia/Riyadh" })).rejects.toThrow("scheduler unavailable");
    expect(saveReminderPreferences).not.toHaveBeenCalled();
    expect(saveReminderSchedule).not.toHaveBeenCalled();
  });

  it("يحاول إيقاف المهمة الجديدة واستعادة حالة القاعدة عند فشل حفظ الجدولة", async () => {
    vi.mocked(getReminderPreferences).mockResolvedValueOnce({ id: null, userId: 7, enabled: false, dailyTime: "08:00", timezone: "UTC", scheduleCronTaskUid: null, nextExecutionAt: null, lastDeliveredDate: null });
    vi.mocked(createReminderCron).mockReturnValue("0 15 6 * * *");
    vi.mocked(createHeartbeatJob).mockResolvedValueOnce({ taskUid: "job-new", nextExecutionAt: "2026-08-19T06:15:00.000Z" } as never);
    vi.mocked(saveReminderSchedule).mockRejectedValueOnce(new Error("database unavailable"));

    await expect(callerFor(7).reminders.configure({ enabled: true, dailyTime: "09:15", timezone: "Asia/Riyadh" })).rejects.toThrow("database unavailable");
    expect(updateHeartbeatJob).toHaveBeenCalledWith("job-new", { enable: false }, "test-token");
    expect(saveReminderSchedule).toHaveBeenNthCalledWith(2, 7, null, null);
    expect(saveReminderPreferences).toHaveBeenCalledWith(7, { enabled: false, dailyTime: "08:00", timezone: "UTC" });
  });

  it("يعلّم تنبيه المستخدم نفسه كمقروء ويرفض الوصول بلا جلسة", async () => {
    await callerFor(7).reminders.markRead({ id: 19 });
    expect(markReminderRead).toHaveBeenCalledWith(7, 19);

    await expect(callerFor(null).reminders.markRead({ id: 19 })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
  });
});

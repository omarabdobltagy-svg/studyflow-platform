import type { Express } from "express";
import { getLibraryAttachmentForDownload } from "../db";
import { isSupportedAttachmentMime } from "../attachments";
import { storageGetSignedUrl } from "../storage";
import { sdk } from "./sdk";

function contentDisposition(fileName: string) {
  const safeFallback = fileName.replace(/[\r\n"\\]/g, "_").replace(/[^\x20-\x7E]/g, "_").slice(0, 150) || "attachment";
  return `attachment; filename="${safeFallback}"; filename*=UTF-8''${encodeURIComponent(fileName)}`;
}

export function registerStorageProxy(app: Express) {
  app.get("/library-attachments/:attachmentId/download", async (req, res) => {
    const attachmentId = Number(req.params.attachmentId);
    if (!Number.isSafeInteger(attachmentId) || attachmentId <= 0) {
      res.status(400).send("Invalid attachment");
      return;
    }

    let user;
    try {
      user = await sdk.authenticateRequest(req);
    } catch {
      res.status(401).send("Authentication required");
      return;
    }
    if (user.isCron || user.id <= 0) {
      res.status(401).send("Authentication required");
      return;
    }

    try {
      const attachment = await getLibraryAttachmentForDownload(user.id, attachmentId);
      if (!attachment) {
        // Keep the response identical for missing and foreign attachments.
        res.status(404).send("Attachment not found");
        return;
      }

      const signedUrl = await storageGetSignedUrl(attachment.fileKey);
      const destination = new URL(signedUrl);
      if (destination.protocol !== "https:") {
        console.error("[StorageProxy] Refusing a non-HTTPS signed storage URL");
        res.status(502).send("Storage backend returned an invalid URL");
        return;
      }

      if (!Number.isSafeInteger(attachment.sizeBytes) || attachment.sizeBytes <= 0 || attachment.sizeBytes > 8 * 1024 * 1024) {
        console.error("[StorageProxy] Stored attachment size is outside the accepted range");
        res.status(502).send("Attachment metadata is invalid");
        return;
      }
      const fileResponse = await fetch(destination, { signal: AbortSignal.timeout(20_000), redirect: "error" });
      if (!fileResponse.ok || !fileResponse.body) {
        console.error(`[StorageProxy] Object storage responded with ${fileResponse.status}`);
        res.status(502).send("Unable to retrieve attachment");
        return;
      }
      const reportedLength = Number(fileResponse.headers.get("content-length"));
      if (Number.isFinite(reportedLength) && reportedLength > 8 * 1024 * 1024) {
        res.status(502).send("Attachment exceeds the accepted size limit");
        return;
      }
      // Read with a hard cap. arrayBuffer() would allocate the entire upstream
      // response before checking its size, allowing a storage error to exhaust RAM.
      const reader = fileResponse.body.getReader();
      const chunks: Buffer[] = [];
      let receivedBytes = 0;
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          receivedBytes += value.byteLength;
          if (receivedBytes > 8 * 1024 * 1024 || receivedBytes > attachment.sizeBytes) {
            await reader.cancel();
            res.status(502).send("Attachment exceeds its stored size");
            return;
          }
          chunks.push(Buffer.from(value));
        }
      } finally {
        reader.releaseLock();
      }
      if (receivedBytes !== attachment.sizeBytes) {
        console.error("[StorageProxy] Attachment size did not match the stored metadata");
        res.status(502).send("Attachment integrity check failed");
        return;
      }
      const bytes = Buffer.concat(chunks, receivedBytes);

      res.set({
        "Content-Type": isSupportedAttachmentMime(attachment.mimeType) ? attachment.mimeType : "application/octet-stream",
        "Content-Length": String(bytes.byteLength),
        "Content-Disposition": contentDisposition(attachment.fileName),
        "Cache-Control": "private, no-store, max-age=0",
        Pragma: "no-cache",
        Vary: "Cookie, Authorization",
        "X-Content-Type-Options": "nosniff",
        "Content-Security-Policy": "sandbox; default-src 'none'",
      });
      res.status(200).send(bytes);
    } catch (error) {
      console.error("[StorageProxy] Download failed:", error);
      res.status(502).send("Unable to retrieve attachment");
    }
  });
}

import { afterEach, describe, expect, it, vi } from "vitest";
import { setDbForTests } from "./db";
import { appRouter } from "./routers";

function callerFor(userId: number | null) {
  return appRouter.createCaller({
    user: userId === null ? null : ({ id: userId, openId: `user-${userId}`, name: "مستخدم الاختبار", role: "user" } as never),
    req: { headers: { cookie: "app_session_id=test-token" } } as never,
    res: {} as never,
  });
}

function createPlanApprovalDbMock() {
  const insertValues = vi.fn()
    .mockResolvedValueOnce([{ insertId: 100 }])
    .mockResolvedValueOnce([{ insertId: 101 }])
    .mockResolvedValueOnce([{ insertId: 201 }])
    .mockResolvedValueOnce([{ insertId: 102 }])
    .mockResolvedValueOnce([{ insertId: 202 }]);
  const insert = vi.fn(() => ({ values: insertValues }));
  const transaction = vi.fn(async (callback: (tx: { insert: typeof insert }) => Promise<unknown>) => callback({ insert }));
  return { db: { transaction }, transaction, insertValues };
}

afterEach(() => setDbForTests(undefined));

describe("عقد اعتماد خطة الدورة", () => {
  it("يمرر هوية المستخدم والخطة المعتمدة من الإجراء المحمي حتى إنشاء الهدف والمراحل والمهام", async () => {
    const mock = createPlanApprovalDbMock();
    setDbForTests(mock.db as never);
    const plan = {
      title: "أساسيات النحو",
      summary: "خطة مركزة لمراجعة أساسيات النحو في جلستين.",
      steps: [
        { day: "الجلسة الأولى", title: "المبتدأ والخبر", detail: "شاهد الدرس واكتب الأمثلة الأساسية.", minutes: 45, category: "نحو" },
        { day: "الجلسة الثانية", title: "تدريبات الإعراب", detail: "أعرب عشر جمل مع مراجعة الإجابات.", minutes: 35, category: "نحو" },
      ],
    };

    await expect(callerFor(null).plans.approve({ plan })).rejects.toMatchObject({ code: "UNAUTHORIZED" });
    await expect(callerFor(7).plans.approve({ plan })).resolves.toEqual({ parentGoalId: 100, stageCount: 2, taskCount: 2 });
    expect(mock.transaction).toHaveBeenCalledOnce();
    expect(mock.insertValues).toHaveBeenCalledTimes(5);
    expect(mock.insertValues.mock.calls.map(([values]) => values.userId)).toEqual([7, 7, 7, 7, 7]);
    expect(mock.insertValues).toHaveBeenNthCalledWith(2, expect.objectContaining({ parentGoalId: 100, title: "المرحلة 1: المبتدأ والخبر" }));
    expect(mock.insertValues).toHaveBeenNthCalledWith(3, expect.objectContaining({ goalId: 101, title: "المبتدأ والخبر" }));
  });
});

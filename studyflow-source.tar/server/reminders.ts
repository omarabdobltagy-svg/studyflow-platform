import { and, asc, desc, eq } from "drizzle-orm";
import { calendarEvents, reminderNotifications, reminderSettings, routineItems, routines, tasks } from "../drizzle/schema";
import { getDb } from "./db";
import { notifyOwner } from "./_core/notification";

export type ReminderPreferences = {
  enabled: boolean;
  dailyTime: string;
  timezone: string;
};

function utcDateKey(value = new Date()) {
  return value.toISOString().slice(0, 10);
}

function timeZoneParts(date: Date, timezone: string) {
  const fields = new Intl.DateTimeFormat("en-US", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(date);
  const get = (type: Intl.DateTimeFormatPartTypes) => Number(fields.find(part => part.type === type)?.value);
  return { year: get("year"), month: get("month"), day: get("day"), hour: get("hour"), minute: get("minute") };
}

function localDateKey(value: Date, timezone: string) {
  const parts = timeZoneParts(value, timezone);
  return `${parts.year}-${String(parts.month).padStart(2, "0")}-${String(parts.day).padStart(2, "0")}`;
}

function sameLocalDay(value: Date | null, dateKey: string, timezone: string) {
  return value ? localDateKey(new Date(value), timezone) === dateKey : false;
}

type ReminderTaskCandidate = { id: number; title: string; dueAt: Date | null };
type ReminderEventCandidate = { id: number; title: string; startAt: Date | null };
type ReminderRoutineCandidate = { id: number };

export function isReminderAlreadyDelivered(lastDeliveredDate: string | null, dateKey: string) {
  return lastDeliveredDate === dateKey;
}

export function buildDailyReminderDraft(input: { timezone: string; now?: Date; tasks: ReminderTaskCandidate[]; events: ReminderEventCandidate[]; routineItems: ReminderRoutineCandidate[] }) {
  const dateKey = localDateKey(input.now ?? new Date(), input.timezone);
  const dueToday = input.tasks.filter(task => sameLocalDay(task.dueAt, dateKey, input.timezone));
  const todayEvents = input.events.filter(event => sameLocalDay(event.startAt, dateKey, input.timezone));
  const routineItemCount = input.routineItems.length;
  if (!dueToday.length && !todayEvents.length && !routineItemCount) {
    return { dateKey, dueToday, todayEvents, routineItemCount, notification: null };
  }
  const parts: string[] = [];
  if (dueToday.length) parts.push(`لديك ${dueToday.length} مهمة مستحقة اليوم${dueToday.length <= 3 ? `: ${dueToday.slice(0, 3).map(task => task.title).join("، ")}` : ""}.`);
  if (todayEvents.length) parts.push(`ولديك ${todayEvents.length} موعد${todayEvents.length <= 3 ? `: ${todayEvents.slice(0, 3).map(event => event.title).join("، ")}` : ""}.`);
  if (routineItemCount) parts.push(`ولا تنسَ روتينك اليومي (${routineItemCount} خطوة).`);
  return {
    dateKey,
    dueToday,
    todayEvents,
    routineItemCount,
    notification: {
      content: parts.join(" "),
      kind: dueToday.length ? "task" as const : todayEvents.length ? "event" as const : "routine" as const,
      sourceId: dueToday[0]?.id ?? todayEvents[0]?.id ?? input.routineItems[0]?.id ?? null,
    },
  };
}

export function createReminderCron(dailyTime: string, timezone = "UTC", referenceDate = new Date()) {
  const [hour, minute] = dailyTime.split(":").map(Number);
  if (!Number.isInteger(hour) || !Number.isInteger(minute) || hour < 0 || hour > 23 || minute < 0 || minute > 59) throw new Error("وقت التذكير غير صالح.");
  let localToday: ReturnType<typeof timeZoneParts>;
  try { localToday = timeZoneParts(referenceDate, timezone); } catch { throw new Error("المنطقة الزمنية غير صالحة."); }
  const localTargetAsUtc = new Date(Date.UTC(localToday.year, localToday.month - 1, localToday.day, hour, minute));
  const displayedAtTarget = timeZoneParts(localTargetAsUtc, timezone);
  const offsetMinutes = (Date.UTC(displayedAtTarget.year, displayedAtTarget.month - 1, displayedAtTarget.day, displayedAtTarget.hour, displayedAtTarget.minute) - localTargetAsUtc.getTime()) / 60_000;
  const utcTarget = new Date(localTargetAsUtc.getTime() - offsetMinutes * 60_000);
  return `0 ${utcTarget.getUTCMinutes()} ${utcTarget.getUTCHours()} * * *`;
}

export async function getReminderPreferences(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا.");
  const row = (await db.select().from(reminderSettings).where(eq(reminderSettings.userId, userId)).limit(1))[0];
  return row ?? { id: null, userId, enabled: false, dailyTime: "08:00", timezone: "UTC", scheduleCronTaskUid: null, nextExecutionAt: null, lastDeliveredDate: null };
}

export async function saveReminderPreferences(userId: number, input: ReminderPreferences) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا.");
  await db.insert(reminderSettings).values({ userId, ...input }).onDuplicateKeyUpdate({ set: { enabled: input.enabled, dailyTime: input.dailyTime, timezone: input.timezone } });
  return getReminderPreferences(userId);
}

export async function saveReminderSchedule(userId: number, scheduleCronTaskUid: string | null, nextExecutionAt: Date | null) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا.");
  await db.update(reminderSettings).set({ scheduleCronTaskUid, nextExecutionAt }).where(eq(reminderSettings.userId, userId));
}

export async function listReminderNotifications(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا.");
  return db.select().from(reminderNotifications).where(eq(reminderNotifications.userId, userId)).orderBy(desc(reminderNotifications.createdAt)).limit(12);
}

export async function markReminderRead(userId: number, id: number) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا.");
  await db.update(reminderNotifications).set({ readAt: new Date() }).where(and(eq(reminderNotifications.id, id), eq(reminderNotifications.userId, userId)));
}

export async function processScheduledReminder(taskUid: string) {
  const db = await getDb();
  if (!db) throw new Error("قاعدة البيانات غير متاحة حاليًا.");
  const setting = (await db.select().from(reminderSettings).where(eq(reminderSettings.scheduleCronTaskUid, taskUid)).limit(1))[0];
  if (!setting || !setting.enabled) return { ok: true, skipped: "disabled-or-orphan" };

  const today = localDateKey(new Date(), setting.timezone);
  if (isReminderAlreadyDelivered(setting.lastDeliveredDate, today)) return { ok: true, skipped: "already-delivered" };

  const [openTasks, events, routineRows] = await Promise.all([
    db.select({ id: tasks.id, title: tasks.title, dueAt: tasks.dueAt, priority: tasks.priority }).from(tasks).where(and(eq(tasks.userId, setting.userId), eq(tasks.status, "todo"))).orderBy(asc(tasks.dueAt)).limit(30),
    db.select({ id: calendarEvents.id, title: calendarEvents.title, startAt: calendarEvents.startAt }).from(calendarEvents).where(eq(calendarEvents.userId, setting.userId)).orderBy(asc(calendarEvents.startAt)).limit(40),
    db.select({ id: routineItems.id }).from(routineItems).innerJoin(routines, eq(routineItems.routineId, routines.id)).where(and(eq(routines.userId, setting.userId), eq(routines.isActive, true), eq(routineItems.isActive, true))).limit(40),
  ]);
  const draft = buildDailyReminderDraft({ timezone: setting.timezone, tasks: openTasks, events, routineItems: routineRows });
  if (!draft.notification) {
    await db.update(reminderSettings).set({ lastDeliveredDate: draft.dateKey }).where(eq(reminderSettings.id, setting.id));
    return { ok: true, skipped: "nothing-to-remind" };
  }
  await db.insert(reminderNotifications).values({ userId: setting.userId, title: "تذكير مسار التعلّم", content: draft.notification.content, kind: draft.notification.kind, sourceId: draft.notification.sourceId, scheduledFor: new Date() });
  await db.update(reminderSettings).set({ lastDeliveredDate: draft.dateKey }).where(eq(reminderSettings.id, setting.id));
  const ownerNotified = await notifyOwner({ title: "تذكير مسار التعلّم", content: draft.notification.content });
  return { ok: true, delivered: true, ownerNotified, taskCount: draft.dueToday.length, eventCount: draft.todayEvents.length, routineItemCount: draft.routineItemCount };
}

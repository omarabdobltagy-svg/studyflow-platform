import { describe, expect, it } from "vitest";
import { parseGeneratedPlan } from "./planGenerator";

const validPlan = JSON.stringify({
  title: "خطة مراجعة الفيزياء",
  summary: "خطة هادئة لمراجعة المفاهيم وحل المسائل في أسبوع واحد.",
  durationLabel: "7 أيام · 60 دقيقة يوميًا",
  steps: [
    { day: "اليوم الأول", title: "تجهيز الملخص", detail: "راجع العناوين الكبرى واكتب الأسئلة الأساسية.", minutes: 45, category: "مراجعة" },
    { day: "اليوم الثاني", title: "حل مسائل الحركة", detail: "حل مجموعة قصيرة وسجّل مواضع التعثر.", minutes: 60, category: "تطبيق" },
    { day: "اليوم الثالث", title: "مراجعة نشطة", detail: "استرجع القوانين من الذاكرة ثم صححها.", minutes: 40, category: "تثبيت" },
  ],
  habits: [{ title: "بداية بلا تردد", cue: "بعد تحضير مشروب المساء" }],
  reviewQuestion: "ما القانون الذي ما زلت تحتاج إلى تطبيقه أكثر من مرة؟",
});

describe("parseGeneratedPlan", () => {
  it("يعيد خطة منظمة عندما تطابق الاستجابة العقد المطلوب", () => {
    const plan = parseGeneratedPlan(validPlan);
    expect(plan.title).toBe("خطة مراجعة الفيزياء");
    expect(plan.steps).toHaveLength(3);
    expect(plan.steps[1]?.minutes).toBe(60);
  });

  it("يرفض النص غير القابل للتحويل إلى JSON", () => {
    expect(() => parseGeneratedPlan("هذه ليست استجابة JSON")).toThrow("تعذّر تحويل الخطة الذكية");
  });

  it("يرفض الخطة الناقصة حتى لا تظهر نتيجة غير موثوقة للمستخدم", () => {
    expect(() => parseGeneratedPlan(JSON.stringify({ title: "خطة فقط" }))).toThrow("الاستجابة الذكية غير مكتملة");
  });
});

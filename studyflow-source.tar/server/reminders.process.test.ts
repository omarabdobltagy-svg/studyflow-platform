import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("./_core/notification", () => ({ notifyOwner: vi.fn(async () => true) }));

import { setDbForTests } from "./db";
import { processScheduledReminder } from "./reminders";

function createDbMock(selectResults: unknown[][]) {
  const select = vi.fn(() => {
    const result = selectResults.shift() ?? [];
    const limit = vi.fn(async () => result);
    const query = { where: vi.fn(() => ({ limit, orderBy: vi.fn(() => ({ limit })) })) };
    return { from: vi.fn(() => ({ ...query, innerJoin: vi.fn(() => query) })) };
  });
  const updateWhere = vi.fn(async () => [{ affectedRows: 1 }]);
  const updateSet = vi.fn(() => ({ where: updateWhere }));
  const update = vi.fn(() => ({ set: updateSet }));
  const insertValues = vi.fn(async () => [{ insertId: 40 }]);
  const insert = vi.fn(() => ({ values: insertValues }));
  return { db: { select, update, insert }, select, updateSet, insertValues };
}

function todayInRiyadh() {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "Asia/Riyadh", year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(new Date());
  const part = (type: Intl.DateTimeFormatPartTypes) => parts.find(item => item.type === type)?.value;
  return `${part("year")}-${part("month")}-${part("day")}`;
}

afterEach(() => setDbForTests(undefined));

describe("المعالجة الفعلية للتذكير المجدول", () => {
  it("يتخطى التذكير الذي سُلّم مسبقًا في اليوم المحلي نفسه دون إنشاء سجل جديد", async () => {
    const mock = createDbMock([[{ id: 1, userId: 7, enabled: true, timezone: "Asia/Riyadh", lastDeliveredDate: todayInRiyadh() }]]);
    setDbForTests(mock.db as never);

    const result = await processScheduledReminder("task-uid");

    expect(result).toEqual({ ok: true, skipped: "already-delivered" });
    expect(mock.select).toHaveBeenCalledOnce();
    expect(mock.insertValues).not.toHaveBeenCalled();
  });

  it("يسجل يوم التسليم فقط عندما لا توجد مهام أو مواعيد أو خطوات روتين", async () => {
    const mock = createDbMock([[{ id: 1, userId: 7, enabled: true, timezone: "Asia/Riyadh", lastDeliveredDate: null }], [], [], []]);
    setDbForTests(mock.db as never);

    const result = await processScheduledReminder("task-uid");

    expect(result).toEqual({ ok: true, skipped: "nothing-to-remind" });
    expect(mock.updateSet).toHaveBeenCalledWith(expect.objectContaining({ lastDeliveredDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/) }));
    expect(mock.insertValues).not.toHaveBeenCalled();
  });

  it("ينشئ سجلًا بالمصدر والنوع الصحيحين ثم يحدّث تاريخ التسليم", async () => {
    const today = todayInRiyadh();
    const mock = createDbMock([
      [{ id: 1, userId: 7, enabled: true, timezone: "Asia/Riyadh", lastDeliveredDate: null }],
      [{ id: 12, title: "حل التمارين", dueAt: new Date(`${today}T12:00:00+03:00`), priority: "high" }],
      [{ id: 24, title: "جلسة مراجعة", startAt: new Date(`${today}T15:00:00+03:00`) }],
      [{ id: 36 }],
    ]);
    setDbForTests(mock.db as never);

    const result = await processScheduledReminder("task-uid");

    expect(result).toMatchObject({ ok: true, delivered: true, ownerNotified: true, taskCount: 1, eventCount: 1, routineItemCount: 1 });
    expect(mock.insertValues).toHaveBeenCalledWith(expect.objectContaining({ userId: 7, title: "تذكير مسار التعلّم", kind: "task", sourceId: 12 }));
    expect(mock.insertValues.mock.calls[0][0].content).toContain("حل التمارين");
    expect(mock.updateSet).toHaveBeenCalledWith(expect.objectContaining({ lastDeliveredDate: expect.stringMatching(/^\d{4}-\d{2}-\d{2}$/) }));
  });
});
